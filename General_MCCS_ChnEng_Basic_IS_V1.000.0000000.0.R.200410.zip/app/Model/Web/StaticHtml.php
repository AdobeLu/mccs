<?php
namespace App\Model\Web;

use App\Model\Base\BaseModel;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class StaticHtml extends BaseModel
{
    protected $table = 'static_htmls';
    protected $fillable = ['name', 'origin_name', 'real_path', 'status', 'user_id','link','zip_path','upload_times'];
    
    /**
     * 
     * @param array $userIds
     * @return 
     */
    public static function deleteByUserIds(Array $userIds){
        $datas = StaticHtml::query()->whereIn('user_id', $userIds)->get();
        if($datas && count($datas)){
            HtmlDelete::addAllDatas($datas->toArray());
            
            StaticHtml::whereIn('user_id', $userIds)->delete();
        }
    }
    
    /**
     *
     * @param $userId
     * @return
     */
    public static function deleteByUserId($userId){
        $userIds = array($userId);
        StaticHtml::deleteByUserIds($userIds);
    }
    
    public static function deleteByIds(Array $ids){
        $user = Auth::user();
        $datas = StaticHtml::query()->whereIn('id', $ids)->where('user_id',$user->id)->get();
        $res = 0;
        if($datas && count($datas->toArray())){
            DB::beginTransaction();
            try{
                HtmlDelete::addAllDatas($datas->toArray());
                $res = StaticHtml::destroy($ids);
                DB::commit();
            }catch (\Exception $e) {
                $res = 0;
                DB::rollBack();
            }  
        }
        return $res;
    }
    
    public static function deleteById($id){
        $ids = array($id);
        return StaticHtml::deleteByIds($ids);
    }
}

