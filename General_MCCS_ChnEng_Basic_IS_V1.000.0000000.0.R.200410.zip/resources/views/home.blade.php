@extends('layouts.app')

@section('content')
<div>
  @if(session()->get('success'))
    <div class="col-8 m-auto alert alert-success alert-dismissible">
      <button id="sucBtn" type="button" class="close" data-dismiss="alert">&times;</button>{{ session()->get('success') }}  
    </div>
  @endif
  @if(session()->get('failed'))
    <div class="col-8 m-auto alert alert-danger alert-dismissible">
      <button id="danBtn" type="button" class="close" data-dismiss="alert">&times;</button>{{ session()->get('failed') }}  
    </div>
  @endif
</div>
<div id="showError">
</div>
<nav class="navbar navbar-expand-lg navbar-light col-8 m-auto" id="app">
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active mr-sm-2" style="cursor:pointer;display: flex;" onclick="addUser()" id='userAddBtn'>
     	 <img src="{{asset('image/add_n.png')}}" class="icon"><span style="align-self:center;margin-left: 10px">{{ __("user.userAddTitle")}}</span>
      </li>
      <li id="mutiDelBtn" class="nav-item active mr-sm-2 disabled text-black-50" style="cursor:pointer;display: flex;;margin-left: 20px">
      	<img id='deleteImg' src="{{asset('image/delete_d.png')}}" class="icon"><span style="align-self:center;margin-left: 10px">{{ __("common.Delete")}}</span>
      </li>
      <!--<li class="nav-item active mr-sm-2" style="cursor:pointer;display: flex;;margin-left: 20px">
        <img src="{{asset('image/offline_n.png')}}" class="icon"><span style="align-self:center;margin-left: 10px">{{ __("user.appDrop")}}</span>
       </li> -->
    </ul>
  </div>
</nav>
<p></p>
<!-- Modal -->
<div class="modal fade" id="deleteConfirm" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">

      <div class="modal-body">
        <div style="padding-top: 20px;">
        	{{ __("user.delete_confirm")}}
        </div>
      </div>
      <div class="modal-footer">
      	<input type="hidden" id="ids"/>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">{{__('common.Cancel')}}</button>
        <button type="button" onclick="urlSubmit()" class="btn btn-primary" data-dismiss="modal">{{__('common.Delete')}}</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">{{ __("user.userAddTitle")}}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="card-body">
            <form id="registerForm" method="POST" action="{{ route('add') }}">
                @csrf
                <input type="hidden" id="pk" name="pk">
                <div class="form-group row" style="word-break:break-all">
                    <label for="name" class="col-md-3 col-form-label text-md-right">{{ __("user.userAddName")}}:</label>
                    <div class="col-md-7" id="nameDiv">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="password" class="col-md-3 col-form-label text-md-right">{{ __("user.userAddPassword")}}:</label>

                    <div class="col-md-7" id="passwordDiv">
                    </div>
                </div>
				
                <div class="form-group row">
                    <label for="password-confirm" class=" col-md-3 col-form-label text-md-right">{{ __("user.userAddConfirm")}}:</label>

                    <div class="col-md-7" id="confirmDiv">
                        <input id="password-confirm" type="password" class="form-control onlyNumAlphaSepCharPwd" name="password_confirmation" required autocomplete="off">
                    </div>
                </div>
                <div class="modal-footer">
<!--                     <button type="button" class="btn btn-secondary" data-dismiss="modal">{{ __("common.Close")}}</button> -->
                    <button id="userBtn" type="button" class="btn btn-primary" disabled>{{ __("common.Save")}}</button>
                </div>
            </form>
        </div>
    </div>
  </div>
</div>
<div class="col-8 m-auto" role="status">
<span class="sr-only">Loading...</span>
    <form id="userListForm" method="POST" action="{{ route('user.mutiDestroy') }}">
     
      	<table id="myTable" class="table table-hover">
      	<thead>
        <tr>
          <th scope="col" style="width: 40px">
          	<div class="form-check form-check-inline">
      			<input class="form-check-input" type="checkbox" id="all" value="option1">
    		</div>
    	  </th>
          <th scope="col" style="width: 20%"><span style="font-size: 1.2rem">{{ __("user.userAddName")}}</span></th>
          <th scope="col" style="text-align: center;width: 34%"><span style="font-size: 1.2rem">{{ __("user.userAddType")}}</span></th>
          <th scope="col" style="text-align: center;width: 40%"><span style="font-size: 1.2rem">{{ __("user.userAddOperation")}}</span></th>
        </tr>
      	</thead>
      	<tbody>
        @foreach($user as $users)
        <tr>
          <th scope="row" style="vertical-align: middle;">
          	<div class="form-check form-check-inline">
          		@if ($users->accountType == 'normal') 
                  	<input class="form-check-input" type="checkbox" name="sub[]" value="{{$users->id}}">
                @elseif ($users->accountType == 'admin')
                  	
                @endif
    		</div>
          </th>
          <td style="vertical-align: middle;">{{$users->name}}</td>
          <td style="vertical-align: middle;text-align: center;">
              @if ($users->accountType == 'normal') 
              	普通用户 
              @elseif ($users->accountType == 'admin')
              	管理员
              @endif
          </td>
          <td style="text-align: center">
              @csrf          
              <!--  <button name="delBtn" class="btn @if ($users->accountType == 'admin') disabled @endif" type="button" onclick="@if ($users->accountType == 'normal') del('{{$users->id}}') @endif">{{__('user.appDrop')}}</button>-->
              <button name="resetBtn" class="btn btn-disabled @if ($users->accountType == 'admin') disabled @endif" style="font-size: 1rem;" type="button" onclick="edit({{$users}}, '{{ route('user.update', $users->id)}}')">{{__('common.ResetPwd')}}</button>
              <button name="delBtn" class="btn text-danger @if ($users->accountType == 'admin') disabled @endif" style="font-size: 1rem;" type="button" data-toggle="modal" data-target="#deleteConfirm" onclick="del('{{$users->id}}')">{{__('common.Delete')}}</button>
          </td>
        </tr>
        @endforeach
      	</tbody>
    </table>
    <div class="float-right paginate">
        {{ $user->links() }}
	</div>
   </form>
</div>
<script src="{{ asset('js/jsEncrypt.js') }}" defer></script>
<script src="{{ asset('js/home.js') }}"></script>
<script>

function urlSubmit() {
	home_urlSubmit('{{ route("user.destroy")}}',"{{ csrf_token() }}","{{__('user.userDeleteSuccess')}}");
}

function edit(user, updateUrl) {
	home_edit(user,updateUrl,'{{ __("common.ResetPwd")}}');
}

function addUser() {
	home_addUser("{{ route('add') }}");
}

window.addEventListener('DOMContentLoaded', function() {
	$("#all").on('click',function() {
          $("input[name='sub[]']").prop("checked", this.checked);  
    	  var $subs = $("input[name='sub[]']");
		  $("#deleteImg").attr('src', $subs.filter(":checked").length > 0 ? "{{ asset('image/delete_n.png')}}":"{{ asset('image/delete_d.png')}}"); 
		  $subs.filter(":checked").length > 0 ?$("#mutiDelBtn").removeClass('text-black-50'):$("#mutiDelBtn").addClass('text-black-50');
    });  
    $("input[name='sub[]']").on('click',function() {  
          var $subs = $("input[name='sub[]']");  
          $("#all").prop("checked" , $subs.length == $subs.filter(":checked").length ? true :false); 
    	  $("#deleteImg").attr('src', $subs.filter(":checked").length > 0 ? "{{ asset('image/delete_n.png')}}":"{{ asset('image/delete_d.png')}}");
    	  $subs.filter(":checked").length > 0 ?$("#mutiDelBtn").removeClass('text-black-50'):$("#mutiDelBtn").addClass('text-black-50');
    }); 
});
</script>
    
@endsection
