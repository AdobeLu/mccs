function del(userId) {
    $("#ids").val(userId);
    $('#deleteConfirm').modal('toggle');
}

function home_urlSubmit(url, csrfToken, msg) {
    if ($('#ids').val() == '') {
        $('#userListForm').submit();
    } else {
        $.ajax({
            url: url,
            type: "POST",
            data: {
                '_token': csrfToken,
                'keys': [$("#ids").val()]
            },
            success: function(data) {
                setTimeout(function() {
                    window.location.reload();
                }, 1000);
                var showErrorStr = "<div class='col-8 m-auto alert alert-success alert-dismissible'>" +
                    "<button type='button' class='close' data-dismiss='alert'>&times;</button>" + msg +
                    "</div>";
                var $showErrorHtml = $(showErrorStr);
                $('#showError').append($showErrorHtml);
                $('#exampleModal').modal('hide');
            },
            //处理完成
            complete: function() {},
            //报错
            error: function(data) {

            }
        });
    }
}

function home_edit(user, updateUrl, title) {
    $('#nameDiv').empty();
    $('#passwordDiv').empty();
    var nameHtml = getEditHTML(user.name);
    var passwordHtml = getPasswordHTML(false);
    var $nameHtml = $(nameHtml);
    var $passwordHtml = $(passwordHtml);
    $('#nameDiv').append($nameHtml);
    $('#passwordDiv').append($passwordHtml);
    $(".onlyNumAlphaSymble").onlyNumAlphaSymble();
    $(".onlyNumAlphaSepCharPwd").onlyNumAlphaSepCharPwd();
    $('#registerForm').attr('action', updateUrl);
    $('#userBtn').attr('disabled', true);
    checkName = false;
    $('#exampleModal').modal('toggle');
    $('#exampleModal').find('.modal-title').text(title);
}

function getNameHTML(showError, error) {
    var html = '<input id="name" type="text" class="onlyNumAlphaSymble form-control' + (showError ? ' is-invalid ' : '') + '" name="name" required maxlength="64" autocomplete="name">' + (showError ? '<span class="invalid-feedback" role="alert">' : '') + (showError ? '<strong>' + error + '</strong>' : '') + (showError ? '</span>' : '');
    return html;
}

function getEditHTML(name) {
    var html = ' <label for="name" class="col-form-label text-md-left">' + name + '</label>';
    return html;
}

function getPasswordHTML(showError, error) {
    var html = '<input id="password" type="password" class="onlyNumAlphaSepCharPwd form-control' + (showError ? ' is-invalid' : '') + '" maxlength="32" name="password" required autocomplete="new-password">' + (!showError ? '<span class="text-danger role="alert" style="font-size: 80%;"><strong>8-32位的数字字母符号组合（区分大小写）</strong></span>' : '') + (showError ? '<span class="invalid-feedback" role="alert">' : '') + (showError ? '<strong>' + error + '</strong>' : '') + (showError ? '</span>' : '');
    return html;
}

function noUserSelected() {
    var html = '<div class="col-8 m-auto alert alert-danger alert-dismissible fade show" aria-hidden="true">' + '<button type="button" class="close" data-dismiss="alert">&times;</button>' + '<strong>错误!</strong> 至少选择一条记录' + '</div>';
    return html;
}

function addHTML(showError) {
    $('#nameDiv').empty();
    $('#passwordDiv').empty();
    var nameHtml = getNameHTML(showError);
    var passwordHtml = getPasswordHTML(showError);
    var $nameHtml = $(nameHtml);
    var $passwordHtml = $(passwordHtml);
    $('#nameDiv').append($nameHtml);
    $('#passwordDiv').append($passwordHtml);
    $(".onlyNumAlphaSymble").onlyNumAlphaSymble();
    $(".onlyNumAlphaSepCharPwd").onlyNumAlphaSepCharPwd();
}

function home_addUser(url) {
    addHTML(false);
    checkName = true;
    $('#userBtn').attr('disabled', true);
    $('#registerForm').attr('action', url);
    $('#exampleModal').modal('toggle');
}
var checkName = true;

$('#nameDiv').on("input propertychange", "#name", function() {
    $('#name').on("input propertychange", function() {
        if ($('#name').val().trim() != '' && $('#password').val().trim() != '' && $('#password-confirm').val().trim() != '') {
            $('#userBtn').removeAttr('disabled');
        } else {
            $('#userBtn').attr('disabled', true);
        }
        if ($(this).val().length > 64) {
            $(this).val($(this).val().substring(0, 64));
        }
    });
});

$('#passwordDiv').on("input propertychange", "#password", function() {
    $('#password').on("input propertychange", function() {
        if ($('#password').val().trim() != '' && (checkName ? $('#name').val().trim() != '' : true) && $('#password-confirm').val().trim() != '') {
            $('#userBtn').removeAttr('disabled');
        } else {
            $('#userBtn').attr('disabled', true);
        }
        if ($(this).val().length > 32) {
            $(this).val($(this).val().substring(0, 32));
        }
    });
});

window.addEventListener('DOMContentLoaded', function() {
    $('#exampleModal').on('show.bs.modal', function(event) {
        var button = $(event.relatedTarget); // 触发事件的按钮
        var recipient = button.data('whatever'); // 解析出data-whatever内容
        var modal = $(this);
        if ($.isEmptyObject(recipient)) {
            modal.find('.modal-title').text('添加新用户');
            modal.find('.modal-body input').val('');
            modal.find('.modal-body textarea').val('');
        }
    });
    $("#exampleModal").on("hidden.bs.modal", function() {
        $(this).removeData("bs.modal");
        clearForm('#registerForm');
    });
    //清空文本框内容
    function clearForm(form) {
        // input清空
        $(':input', form).each(function() {
            var type = this.type;
            var tag = this.tagName.toLowerCase(); // normalize case
            if (tag == 'select')
                this.selectedIndex = -1;
            else if (type != 'hidden')
                this.value = "";
        });
    };
    $('#mutiDelBtn').on('click', function() {
        var $subs = $("input[name='sub[]']");
        if ($subs.filter(":checked").length == 0) {
            return;
        }
        $('#deleteConfirm').modal('toggle');
    });

    $('#userBtn').click(function() {
        var oriPwd = $('#password').val();
        var oriConfirmPwd = $('#password-confirm').val();
        $.ajax({
            url: 'getPK',
            type: "GET",
            dataType: 'json',
            async: false,
            success: function(data) {
                var encrypt = new JSEncrypt();
                encrypt.setPublicKey(atob(data.pk));
                var password = encrypt.encrypt($('#password').val());
                var password_confirm = encrypt.encrypt($('#password-confirm').val());
                $('#password').val(password);
                $('#password-confirm').val(password_confirm);
                var timestamp = Date.parse(new Date());
                $('#pk').val(data.pk);
                sendData();
            },
            //处理完成
            complete: function() {
                $('#password').val(oriPwd);
                $('#password').val(oriConfirmPwd);
            },
            //报错
            error: function(data) {
                console.log(data.responseText);
            }
        });
    });

    function sendData() {
        var form = document.getElementById('registerForm');
        var formData = signFormData(form, false);
        $.ajax({
            url: form.action,
            type: 'POST',
            data: signFormData(form, false),
            processData: false,
            contentType: false,
            success: function(data) {
                setTimeout(function() {
                    window.location.reload();
                }, 1000);
                var showErrorStr = "<div class='col-8 m-auto alert alert-success alert-dismissible'>" +
                    "<button type='button' class='close' data-dismiss='alert'>&times;</button>添加成功!" +
                    "</div>";
                var $showErrorHtml = $(showErrorStr);
                $('#showError').append($showErrorHtml);
                $('#exampleModal').modal('hide');
            },
            //处理完成
            complete: function() {},
            //报错
            error: function(data) {
                if (data.status == 422) {
                    var errors = JSON.parse(data.responseText).errors;
                    if (errors.hasOwnProperty("name") && errors.name.length > 0) {
                        $('#nameDiv').empty();
                        var nameHtml = getNameHTML(true, errors.name[0]);
                        var $nameHtml = $(nameHtml);
                        $('#nameDiv').append($nameHtml);
                        $('#userBtn').attr('disabled', true);
                    } else {
                        $('#name').removeClass('is-invalid');
                    }
                    if (errors.hasOwnProperty("password") && errors.password.length > 0) {
                        $('#passwordDiv').empty();
                        var passwordHtml = getPasswordHTML(true, errors.password[0]);
                        var $passwordHtml = $(passwordHtml);
                        $('#passwordDiv').append($passwordHtml);
                        $('#password-confirm').val('');
                        $('#userBtn').attr('disabled', true);
                    } else {
                        $('#password').removeClass('is-invalid');
                    }
                    $(".onlyNumAlphaSymble").onlyNumAlphaSymble();
                    $(".onlyNumAlphaSepCharPwd").onlyNumAlphaSepCharPwd();
                } else {
                    location.reload();
                }
            }
        });
    }

    $('#password-confirm').on('input propertychange', function() {
        if ($(this).val().trim() != '' && (checkName ? $('#name').val().trim() != '' : true) && $('#password').val().trim() != '') {
            $('#userBtn').removeAttr('disabled');
        } else {
            $('#userBtn').attr('disabled', true);
        }
        if ($(this).val().length > 32) {
            $(this).val($(this).val().substring(0, 32));
        }
    });

    setTimeout(function() {
        $('#sucBtn').click();
        $('#danBtn').click()
    }, 1000);
});