cd /home/jenkins/jk_slave/workspace/PCSoft_DH3.RDA000040_MCCS_linux/code_path
build_date=`date "+%y%m%d"`
version='1.000.0000000.0'
name=General_MCCS_ChnEng_Basic_IS_V${version}.R.${build_date}.zip
zip -r ${name} ./ -x '.svn/*' '/node_modules/*' '/public/hot/*' '/public/storage/*' '/storage/*.key' '/vendor/*' '.env' '.env.backup' '.phpunit.result.cache' 'Homestead.json' 'Homestead.yaml' 'npm-debug.log' 'yarn-error.log'
cp ${name} artifacts/Release