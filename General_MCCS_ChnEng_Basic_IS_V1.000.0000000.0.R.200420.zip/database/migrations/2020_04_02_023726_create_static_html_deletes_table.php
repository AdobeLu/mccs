<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStaticHtmlDeletesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('static_html_deletes', function (Blueprint $table) {
            $table->bigInteger('id')->primary();
            $table->string("name")->comment("项目名称");
            $table->string('link')->unique()->comment("唯一链接");
            $table->string('real_path')->nullable()->comment("解压路径");
            $table->string("zip_path")->nullable()->comment("上传的压缩文件");
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('static_html_deletes');
    }
}
