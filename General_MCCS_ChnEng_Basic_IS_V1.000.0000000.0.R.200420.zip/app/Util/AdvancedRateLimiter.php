<?php
namespace App\Util;
use Illuminate\Cache\RateLimiter;

class AdvancedRateLimiter extends RateLimiter
{
    public function hit($key, $decaySeconds = 60)
    {
        $this->cache->add(
            $key.':timer', $this->availableAt($decaySeconds), $decaySeconds
            );
        
        $added = $this->cache->add($key, 0, $decaySeconds);
        $hits = (int) $this->cache->increment($key);
        if (! $added && $hits == 1) {
            $this->cache->put($key, 1, $decaySeconds);
        }
        if($hits == 5) {
            $this->cache->delete($key.':timer');
            $this->cache->add($key.':timer', $this->availableAt($decaySeconds), $decaySeconds);
            $timpHits = $this->attempts($key);
            $this->cache->delete($key);
            $this->cache->put($key, $timpHits, $decaySeconds);
        }
        
        return $hits;
    }
}

