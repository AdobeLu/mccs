<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\RegisterUserPost;
use App\User;
use App\Util\RSA;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = "/";

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
//         $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => ['required', 'string', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {
        return User::create([
            'name' => $data['name'],
            'password' => Hash::make($data['password']),
        ]);
    }
    
    public function store(RegisterUserPost $request) {
        
        $request->validated();

        $user = new User([
            'name' => $request->get('name'),
            'password' => Hash::make($request->get('password'))
        ]);
        $user->save();
        if ($request->ajax()) {
            $request->session()->flash("success", __("user.userAddSuccess"));
            return response()->json([
                'msg' => __('user.userAddSuccess'),
                'code' =>  __('err.code.c_10000'),
                'success'=>TRUE
            ]);;
        }
        return redirect('home')->with('success', __("user.userAddSuccess"));
    }
    
    public function update(Request $request, $id) {
        
        $rsa = new RSA();
        if (Cache::has($request->get('pk'))) {
            $key = "-----BEGIN PRIVATE KEY-----\n" . wordwrap(Cache::pull($request->get('pk')), 64, "\n", true) . "\n-----END PRIVATE KEY-----";
            $rsa->init($key, $request->get('pk'),true);
        }
        $request['password'] = $rsa->priv_decode($request->get('password'));
        $request['password_confirmation'] = $rsa->priv_decode($request->get('password_confirmation'));
        $request->validate([
            'password' => ['required', 'confirmed',
                function ($attribute, $value, $fail) {
                    $result = preg_match('/^(?=.*[a-zA-Z\\d])(?=.*[a-zA-Z!#$%()*+,-.\/\<\=\>?@[\\]^_`{|}~])(?=.*[\\d!#$%()*+,-.\/\<\=\>?@[\\]^_`{|}~]).{8,32}$/', $value);
                    if ($result != 1) {
                        $fail(__("passwords.password_requirements"));
                        return;
                    }
                }]
        ]);
        
        $user = User::find($id);
        $user->password = Hash::make($request->get('password'));
        $user->save();
        if ($request->ajax()) {
            $request->session()->flash("success", __("user.userUpdateSuccess"));
            return response()->json([
                'msg' => __('user.userUpdateSuccess'),
                'code' =>  __('err.code.c_10000'),
                'success'=>TRUE
            ]);;
        }
        return redirect('home')->with('success', __("user.userUpdateSuccess"));
    }
    
    public function read(Request $request, $id) {
        
        $user = User::find($id);
        return $user;
    }
}
