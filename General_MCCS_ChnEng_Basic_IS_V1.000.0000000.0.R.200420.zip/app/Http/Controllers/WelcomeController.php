<?php
namespace App\Http\Controllers;

use App\Model\Contact;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;


class WelcomeController extends Controller
{
    public function index()
    {
        if($this->isAdmin()){
            return redirect("/home");
        }
        $contacts = null;
        
        try {
            $contacts = Contact::query()
            ->select('name','phone','email')
            ->where('status', '=',0)
            ->orderBy('id')
            ->limit(2)
            ->get();
        } catch (\Exception $e) {
        
        }
        
        $data = [
            'contacts' => $contacts == null ? array() :$contacts->toArray(),
        ];
        //Session::put("message","test");
        return view('welcome',$data);
    }
    
    private function isAdmin(){
        if (Auth::check()) {
            return Auth::user()->accountType == 'admin';
        }
        return FALSE;
    }
}

