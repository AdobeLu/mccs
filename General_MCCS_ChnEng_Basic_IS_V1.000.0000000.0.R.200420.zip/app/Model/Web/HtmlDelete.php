<?php
namespace App\Model\Web;

use App\Model\Base\BaseModel;
use Illuminate\Support\Facades\Storage;

class HtmlDelete extends BaseModel
{
    
    protected $table = 'static_html_deletes';
    protected $fillable = ['id','name', 'real_path', 'link','zip_path'];
    protected $allowEmpty = ['real_path','zip_path'];
    public $timestamps = false;
    
    public static function deleteResource(){
        $ret = HtmlDelete::query()->get();
        if($ret){
            foreach($ret as $item){
                try {
                    if($item['zip_path']){
                        if(Storage::disk('uploads')->exists($item['zip_path'])){
                            Storage::disk('uploads')->delete($item['zip_path']);
                        }
                        if($item['real_path']){
                            Storage::disk('uploads')->deleteDirectory($item['real_path']);
                        }
                    }
                    
                   $item->delete();
                }catch (\Exception $e){
                    
                }
            }
        }
    }
    
    public static function addAllDatas(Array $data){
        $htmlDelete = new HtmlDelete();
        return $htmlDelete->insertMoreStore($data);
    }
    
    public static function addData($data){
        $htmlDelete = new HtmlDelete();
        return $htmlDelete->checkStore($data);
    }
}

