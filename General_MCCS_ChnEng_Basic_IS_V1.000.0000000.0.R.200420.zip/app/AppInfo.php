<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppInfo extends Model
{
    //
    protected $fillable = [
        'appName',//app名称
        'appBundleId',//bundlID、包名
        'appShortLink',//短连接
        'appVersion',//app版本
        'appDistributon',//T or R 版本
        'appSignVersion',//Ad-Hoc、Release、Debug，iOS特有
        'appSignCertName',//签名证书名称
    ];
}
