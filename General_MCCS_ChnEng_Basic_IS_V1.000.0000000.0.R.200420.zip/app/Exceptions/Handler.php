<?php

namespace App\Exceptions;


use Illuminate\Auth\AuthenticationException;
use Illuminate\Http\Exceptions\ThrottleRequestsException;
use Illuminate\Session\TokenMismatchException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Exception;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Symfony\Component\HttpKernel\Exception\HttpException;

class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that are not reported.
     *
     * @var array
     */
    protected $dontReport = [
        //\Illuminate\Auth\AuthenticationException::class,
        //\Illuminate\Auth\Access\AuthorizationException::class,
        //\Symfony\Component\HttpKernel\Exception\HttpException::class,
        //\Illuminate\Database\Eloquent\ModelNotFoundException::class,
        //\Illuminate\Session\TokenMismatchException::class,
        //\Illuminate\Validation\ValidationException::class,

    ];

    /**
     * A list of the inputs that are never flashed for validation exceptions.
     *
     * @var array
     */
    protected $dontFlash = [
        'password',
        'password_confirmation',
    ];

    /**
     * Report or log an exception.
     *
     * @param  \Exception  $exception
     * @return void
     *
     * @throws \Exception
     */
    public function report(Exception $e)
    {
        parent::report($e);
        
    }

    /**
     * Render an exception into an HTTP response.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Exception  $exception
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @throws \Exception
     */
    public function render($request, Exception $e)
    {
        if( $e instanceof AuthenticationException){
            
            if ($request->ajax() || $request->wantsJson()) {
                return  response()->json([
                    'msg' => __('err.401.msg'),
                    'code' => __('err.401.code'),
                    'success'=>false
                ]);
            }
            return parent::render($request, $e);
        }
        if($e instanceof TokenMismatchException){
            if ($request->ajax() || $request->wantsJson()) {
                return  response()->json([
                    'msg' => __('err.419.msg'),
                    'code' => __('err.419.code'),
                    'success'=>false
                ]);
            }else{
                return response()->view("errors.419");
            }
        }
        if($e instanceof \Symfony\Component\ErrorHandler\Error\FatalError) {
                if ($request->ajax() || $request->wantsJson()) {
                    return  response()->json([
                        'msg' => __('err.msg.m_50000'),
                        'code' => __('err.code.c_50000'),
                        'success'=>false
                    ]);
                }else{
                    return response()->view("errors.500");
                }
        }
        if($e instanceof \League\Flysystem\FileExistsException){
            if ($request->ajax() || $request->wantsJson()) {
                return  response()->json([
                    'msg' => __('webs.web_dir_fail'),
                    'code' => __('err.code.c_50000'),
                    'success'=>false
                ]);
            }else{
                return response()->view("errors.500",['msg' => __('webs.web_dir_fail')]);
            }
        }
        if($e instanceof ThrottleRequestsException){
            if ($request->ajax() || $request->wantsJson()) {
                return  response()->json([
                    'msg' => __('err.429.msg'),
                    'code' => __('err.429.code'),
                    'success'=>false
                ]);
            }else{
                return response()->view("errors.429");
            }
        }
        $httpCode = [400,403,404,500,501,502,503,504];
        if($e instanceof HttpException){
           $code = $e->getStatusCode();
           if(in_array($code, $httpCode)){
               if ($request->ajax() || $request->wantsJson()) {
                   return  response()->json([
                       'msg' => __('err.'.$code.'.msg'),
                       'code' => __('err.'.$code.'.code'),
                       'success'=>false
                   ]);
               }else if(view()->exists("errors.".$code)){
                   return response()->view("errors.".$code);
               }else {
                   return response()->view("errors.default",['code' => $code,"msg"=>"未知错误"]);
               }
           }
           
        }
        if ($e instanceof NotFoundHttpException) {
            if ($request->ajax() || $request->wantsJson()) {
                return  response()->json([
                    'msg' => __('err.msg.m_40004'),
                    'code' => __('err.code.c_40004'),
                    'success'=>false
                ]);
            } else {
                return response()->view('errors.404');
            }
        }
        return parent::render($request, $e);
        /*if($request->expectsJson()){
            return  response()->json([
                'msg' => __('err.500.msg'),
                'code' => __('err.500.code'),
                'success'=>false
            ]);
        }else {
            return response()->view("errors.500");
        }*/
    }
    
    /* public function prepareResponse($request, Exception $e)
    {
        if (! $this->isHttpException($e) && config('app.debug')) {
            return $this->toIlluminateResponse($this->convertExceptionToResponse($e), $e);
        }
        
        if (! $this->isHttpException($e)) {
            $e = new HttpException(500, $e->getMessage());
        }
        
        return $this->toIlluminateResponse(
            $this->renderHttpException($e), $e
            );
    } */
}
