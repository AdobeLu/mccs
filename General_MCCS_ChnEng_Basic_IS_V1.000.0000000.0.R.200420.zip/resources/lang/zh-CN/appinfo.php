<?php
return [
    
/*=========================add by luligang==========================*/
    'drag_to_upload' => '拖动到这里上传',
    'upload_first_app' => '在这里上传您的第一个应用吧~',
];
