var signData = function(form, timestamp) {
    var obj = serializeForm(form);
    obj['timestamp'] = timestamp;
    delete obj.sign;
    return md5(jsonSort(obj) + obj._token);
};
var serializeForm = function(form) {
    var parts = {},
        field = null,
        i,
        len,
        j,
        optLen,
        option,
        optValue;
    for (i = 0, len = form.elements.length; i < len; i++) {
        field = form.elements[i];
        switch (field.type) {
            case 'select-one':
            case 'select-multiple':
                if (field.name.length) {
                    optValue = '';
                    for (j = 0, optLen = field.options.length; j < optLen; j++) {
                        option = field.options[j];
                        if (option.selected) {

                            if (option.hasAttribute) {
                                optValue += (option.hasAttribute('value') ? option.value : option.text);
                            } else {
                                optValue += (option.attributes['value'].specified ? option.value : option.text);
                            }
                        }
                    }
                    //parts.set(encodeURIComponent(field.name),encodeURIComponent(optValue));
                    //parts[encodeURIComponent(field.name)] = encodeURIComponent(optValue);
                    parts[field.name] = optValue;
                }
                break;
            case undefined: //字段集
            case 'file':
            case 'submit':
            case 'reset':
            case 'button':
                break;
            case 'radio':
            case 'checkbox':
                if (!field.checked) {
                    break;
                }
            default:
                if (field.name.length) {
                    //parts.set(encodeURIComponent(field.name),encodeURIComponent(field.value));
                    //parts[encodeURIComponent(field.name)] = encodeURIComponent(field.value);
                    parts[field.name] = field.value;
                }
        }
    }
    return parts;
};
var jsonSort = function(jsonObj) {
    let arr = [];
    for (key in jsonObj) {
        arr.push(key);
    }
    arr.sort();
    let str = '';
    for (i in arr) {
        str += arr[i] + "=" + jsonObj[arr[i]] + "&";
    }
    return str;
};

function signFormData(form, trim) {
    var formData = new FormData(form);
    var timestamp = new Date().getTime();
    formData.append("timestamp", timestamp);
    var arr = [];
    for (key of formData.keys()) {
        if (arr.indexOf(key) == -1 && key != 'file') {
            arr.push(key);
        }
    }
    arr.sort();
    var str = '';
    for (i in arr) {
        var a = formData.getAll(arr[i]);
        var key = arr[i];
        if (arr[i].endsWith('[]')) {
            key = key.substring(0, key.length - 2);
            for (j in a) {
                if (trim) {
                    var v = a[j].trim();
                    if (v.length != 0) {
                        //str +=encodeURIComponent(key+"["+j+"]")+"="+encodeURIComponent(v)+"&"
                        str += key + "[" + j + "]" + "=" + v + "&";
                    }
                } else {
                    //str +=encodeURIComponent(key+"["+j+"]")+"="+encodeURIComponent(a[j])+"&"
                    str += key + "[" + j + "]" + "=" + a[j] + "&";
                }

            }
        } else if (a.length > 1) {
            if (trim) {
                var v = a[a.length - 1].trim();
                if (v.length != 0) {
                    //str +=encodeURIComponent(key)+"="+encodeURIComponent(v)+"&"
                    str += key + "=" + v + "&";
                }
            } else {
                //str +=encodeURIComponent(key)+"="+encodeURIComponent(a[a.length-1])+"&"
                str += key + "=" + a[a.length - 1] + "&";
            }

        } else if (a.length == 1) {
            if (trim) {
                var v = a[0].trim();
                if (v.length != 0) {
                    //str +=encodeURIComponent(key)+"="+encodeURIComponent(v)+"&"
                    str += key + "=" + v + "&";
                }
            } else {
                var v = a[0];
                //str +=encodeURIComponent(key)+"="+encodeURIComponent(v)+"&"
                str += key + "=" + v + "&";
            }
        }

    }
    var key = formData.get("_token");
    str += key;
    var sign = md5(str);
    formData.append("sign", sign);
    return formData;
}