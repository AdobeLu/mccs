<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Pragma" content="no-cache"/>
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'MCCS') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/jquery-3.4.1.min.js')}}"></script>
    <script src="{{ asset('js/bootstrap-4.4.1.min.js')}}"></script>
	<script src="{{ asset('js/jsEncrypt.js') }}" defer></script>
	<script src="{{ asset('js/md5.min.js')}}"></script>
	<script src="{{ asset('js/formValidation.js')}}"></script>
	<script src="{{ asset('js/mccs-auth.js') }}" defer></script>
	<script src="{{ asset('js/login.js') }}"></script>
    <!-- Fonts -->

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{ asset('css/appExtension.css') }}" rel="stylesheet">
</head>
<body class="bg-dark">
<div>
<div class="row justify-content-center">
<img src="../image/logo.png" class="img-fluid justify-content-center" style="margin-top: 202px" alt="Responsive image">
</div>
    <div class="row justify-content-center" style="margin-top: 52px;">
        <div class="col-12">
        	<div class="col-sm-9 col-md-7 col-lg-5 col-xl-4 m-auto" style="background-image: url(../image/login_pic_bg.png);height: 605px">
                <div class="col-sm-12 col-md-10 col-lg-8 col-xl-8 card m-auto">
                    <div class="card-whiteHeader">{{ __('common.Login') }}</div>
    
                    <div class="card-body">
                        <form id="loginForm" method="POST" action="{{ route('customLogin') }}" autocomplete="off">
                            <input type="password" style="display: none;" name=""  autocomplete="off" readonly>
                            @csrf
                            <input type='hidden' id="nonce" name="nonce" value="{{$nonce}}">
                            <div class="form-group row">
                                <input id="name" type="text" class="form-control @error('name') is-invalid @enderror onlyNumAlphaSymble" name="name" value="{{ old('name') }}" placeholder="{{__('auth.user_placeholder')}}" maxlength="64" required autocomplete="off" autofocus>
    
                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
<!--      <a class="nav-link text-dark" href="{{ route('register') }}">注册</a> -->
                            <div class="form-group row row-margin-top">
                                <input id="password" type="text" class="form-control @error('password') is-invalid @enderror" style="background-color:#efefef;" placeholder="{{__('auth.password_placeholder')}}" readonly name="password" value="" autocomplete="new-password" onfocus="this.type='password';this.removeAttribute('readonly');">
                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            
                            @if ($attempts > 0) 
                            <div class="form-group row row-margin-top">
								<input id="verCode" class="form-control col-4 @error('verCode') is-invalid @enderror" name="verCode" placeholder="{{__('common.verCode')}}" required><img id="verImg" src="{{captcha_src()}}" style="margin-left: 5px">
                            	@error('verCode')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            @endif
                            <div class="form-group row row-margin-top">
                                <button id="loginBtn" disabled type="button" class="btn btn-primary" style="width: 100%;background-color:#007aff;height:44px">
                                    {{ __('common.Login') }}
                                </button>
                            </div>
                            <input type="hidden" id="timestamp" name="timestamp">
                			<input type="hidden" id="sign" name="sign">
                			<input type="hidden" id="pk" name="pk">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
<script>
window.addEventListener('DOMContentLoaded', function() {
	$('#verImg').on('click', function(){
		
		$('#verImg').attr('src', "{{url('captcha/default')}}"+'?time='+new Date().getTime());
	});
});
</script>
</html>
