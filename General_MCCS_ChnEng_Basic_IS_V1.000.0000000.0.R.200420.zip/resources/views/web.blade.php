<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
   <!--  <meta name="viewport" content="width=device-width, initial-scale=1"> -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{__('webs.web_static_deployment')}}</title>
    <link href="{{ asset('css/mccs.css') }}" rel="stylesheet">
    <link rel="shortcut icon" href="{{ asset('favicon.ico') }}">
</head>
<body>
<div class="top-container">
    @include('top')
</div>

<div class="web-content">
    <div>
    	<div class="web-opt" onclick="createWeb('add-form')">
        	<img src="{{asset('image/add.png')}}" class="icon"><span class="opt-txt">{{ __('webs.new_web') }}</span>
        </div>
        	<form id="add-form" action="{{route('web.new')}}" method="POST" class="mccs-hide">
                @csrf
            </form>
    	<div class="web-opt delete" onclick="showDialog(true,'delete-form-more',null);">
    	     <img src="{{asset('image/delete_d.png')}}" class="icon" id="delete-more-icon"><span class="opt-txt no-check" id="delete-more-txt">{{ __('webs.delete_web') }}</span>
    	</div>
    	<form id="delete-form-more" action="{{route('web.delete.more')}}" method="POST" class="mccs-hide">
    	   @csrf
    	   <input type="hidden" id='ids' value="" name="ids">
    	</form>
    	<div class="mccs-clear"></div>
    </div>
    
    <hr>
    @if($total == 0)
        <div class="web-no-data" onclick="createWeb('add-form')">
        	<div><img  src="{{asset('image/no_web_item.png')}}" /></div>
        	<span>{{ __('webs.no_web_item') }}</span>
        </div>
    @else
        <table>
    	    <tr>
    	    	<th class="t1"><input type="checkbox" id="check-all" name="check-all" onclick="swapCheck()"></th>
    	        <th class="t2">{{ __('webs.web_name') }}</th>
    	        <th class="t4">{{ __('webs.web_link') }}</th> 
    	        <th class="t4">{{ __('webs.web_html_name') }}</th>
    	        <th class="t3">{{ __('webs.web_opt') }}</th> 
    	    </tr>
    	    <tr class="tr-hr">
    	        <td colspan="5"><hr></td>
    	    </tr>
    	    @foreach($data as $item)
                <tr>
        	    	<td class="t1"><input type="checkbox" name="p" value="{{$item['id']}}" onclick="checkChange(this)"></td>
        	        <td class="t2">
        	           <form action="{{route('web.name')}}" method="post" id="form-name-{{$item['id']}}" name="form-name-{{$item['id']}}" class="valign-middle-container {{isset($c_id) && $c_id== $item['id'] ? '' : 'mccs-hide'}}" >
	                      
	                      <input type="hidden" name="id" value="{{$item['id']}}">
	                      @csrf
	                      <input type="text" name="name" id="name-{{$item['id']}}" autocomplete="off" maxlength="64" onkeydown="changeNameDown()" onkeyup="changeNameUp({{$item['id']}},'normal-{{$item['id']}}')" value = "{{ isset($c_id) && $c_id== $item['id'] ? (old('name') ? old('name') : $item['name']) : $item['name'] }}" class="input-name">
	                     
	                      <img  title="{{__('common.Save')}}" src="{{asset('image/web_ok.png')}}" onclick="changeName({{$item['id']}},'normal-{{$item['id']}}')"/>
	                      <img  title="{{__('common.Cancel')}}" src="{{asset('image/web_cancel.png')}}" onclick="changeMode('normal-{{$item['id']}}','form-name-{{$item['id']}}','name-{{$item['id']}}')"/>
        	            </form>
        	            <div id="normal-{{$item['id']}}" class ="singleline {{isset($c_id) && $c_id== $item['id'] ? 'mccs-hide' : ''}}" title="{{$item['name']}}">{{$item['name']}}</div>
        	        </td>
        	        <td class="t4">
        	              <span class="singleline u-name"><a href="{{route('web.link', $item['link'])}}" target="_blank" title="{{route('web.link', $item['link'])}}">{{route('web.link', $item['link'])}}</a></span>
        	              <a href="{{route('web.link', $item['link'])}}" id="qr-{{$item['id']}}" title="{{$item['name']}}" class="qr_code" onclick="event.preventDefault();"><img src="{{asset('image/qr_code.png')}}" width="24px" height="24px"/></a>
                     </td>
        	        <td class="t4">
        	           <form method="POST" enctype="multipart/form-data" id="file-upload-{{$item['id']}}" action="{{route('web.upload')}}" class="mccs-hide">
        	               @csrf
        	               <input type="hidden" name="id" value="{{$item['id']}}">
        	               <input type="hidden" name="file-content" id="file-content-{{$item['id']}}">
        	               <input type="file" name="file" class="file-input" id ="file-{{$item['id']}}" accept=".zip" onchange="fileSelect({{$item['id']}},'file-{{$item['id']}}')"> 
        	           </form>
        	           @if($item['origin_name'] != null)
        	                 
        	                  <a href="{{route('web.download', $item['id'])}}" title="{{$item['origin_name']}}">
        	                       <img src="{{asset('image/zip.png')}}">
                        	       <span class="singleline u-name" >{{$item['origin_name']}}</span>
                    	      </a>
                    	      <span class="btn-upload btn-upload-re" onclick="document.getElementById('file-{{$item['id']}}').click();">{{ __('webs.web_reupload') }}</span>
        	              
                	       
        	           @else
        	               <span class="btn-upload" onclick="document.getElementById('file-{{$item['id']}}').click();">{{ __('webs.web_upload') }}</span>
        	           @endif
        	        </td>
        	        <td class="t3">
        	             <span class="opt" onclick="changeMode('form-name-{{$item['id']}}','normal-{{$item['id']}}')">{{ __('webs.web_modify') }}</span>
        	             <span class="opt" onclick="showDialog(false,'delete-form-{{$item['id']}}','normal-{{$item['id']}}');">{{ __('webs.delete_web') }}</span>
        	             <form id="delete-form-{{$item['id']}}" action="{{route('web.delete')}}" method="POST" class="mccs-hide">
                            @csrf
                            <input type="hidden" name="id" value="{{$item['id']}}">
                         </form>
        	         </td>
        	         
        	    </tr>
    	    @endforeach
            <tr class="tr-hr">
            <td colspan="5"><hr></td>
            </tr>
        </table>
        <div class="nav-right">
           <a class="nav {{ $prev_page_url ? '' : 'nav-disable' }}" href="{{ $prev_page_url != null ? $prev_page_url.'&pageSize='.$per_page : '' }}" onclick="{{ $prev_page_url ? '' : 'event.preventDefault();' }}">&lt;</a>
           
           
           @for($i = ($current_page-5 > 0 ? $current_page-5 : 1); $i < $current_page && $i <= $last_page; $i++)
           <a class="nav" href="{{ URL::current() }}?page={{ $i }}&pageSize={{$per_page}}">{{ $i }}</a>
           @endfor
           @if($current_page <= $last_page)
           <a class="nav nav-current"
               href="{{ URL::current() }}?page={{ $current_page }}&pageSize={{$per_page}}" onclick="event.preventDefault();">{{ $current_page }}</a>
           @endif
           @for($i = $current_page + 1; $i <= ($current_page + 5 > $last_page ? $last_page : $current_page + 5); $i++)
            <a class="nav" href="{{ URL::current() }}?page={{ $i }}&pageSize={{$per_page}}">{{ $i }}</a>
           @endfor

           <a class="nav {{ $next_page_url ? '' : 'nav-disable' }}" href="{{ $next_page_url != null ? $next_page_url.'&pageSize='.$per_page : ''}}" onclick="{{ $next_page_url ? '' : 'event.preventDefault();' }}">&gt;</a>
        </div>
    @endif 
    
</div>
<div class="dialog mccs-hide" id="dialog">
   <div class="dialogContent">
       <div class="dialogTitleP">
          <span id="dialgTitle" class="two-lines"></span>
       </div>
       <div class="dialogWarn">{{ __('webs.web_delete_warn') }}</div>
       <div class="dialogBtnP">
           <button id="cancel">{{ __('webs.web_cacnel') }}</button>
           <button id="ok">{{ __('webs.web_ok') }}</button>
       </div>
   </div>
</div>
<div id="msg-container" class="msg-container mccs-hide">
  <span id="msg-tip"></span>
</div>
<div id="loading" class="mccs-hide">
    <div class="loadingCenter"></div>
</div>
<script src="{{ asset('js/jquery-3.4.1.min.js')}}"></script>
<script src="{{ asset('js/md5.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/spark-md5.min.js')}}"></script>
<script type="text/javascript" src="{{asset('js/jquery.qrcode.min.js')}}"></script>
<script type="text/javascript">
    var delete_more_no_choose = "{{ __('webs.web_delete_no_choose')}}";
    var delete_items = "{{__('webs.web_delete_item')}}";
    var zip_limit = "{{__('webs.web_mimetype_fail')}}";
    var file_size_limit = "{{__('webs.web_file_size',['size' => config('mccs.file_max_size')])}}";
    var file_max_size = {{config('mccs.file_max_size')}};
    var name_limit = "{{__('webs.web_name_limit')}}";
    var name_limit_length = "{{__('webs.web_name_limit_length')}}";
    var name_not_null = "{{__('webs.web_not_null')}}";
    var name_save_success = "{{__('webs.web_modify_success')}}";
    var web_qr_export = "{{__('webs.web_qr_export')}}";
    var web_internal_error = "{{__('webs.web_internal_error')}}";
    var web_parse_fail = "{{__('webs.web_file_md5_fail')}}";
</script>
<script src="{{ asset('js/web.js') }}"></script>
@if(session('message') != null)
<script type="text/javascript">
   showMsg('{{session('message')}}',true);
</script>  
@endif
</body>
</html>
