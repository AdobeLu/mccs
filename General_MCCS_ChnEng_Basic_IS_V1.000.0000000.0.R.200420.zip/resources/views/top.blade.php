<div class="top">
    	<div class="logo">
    	    @auth
    		   @if(Auth::user()['accountType'] == 'normal')
    		      <a href="{{route('index')}}"><img src="{{asset('image/logo.png')}}"></a>
    		   @else
    		     <img src="{{asset('image/logo.png')}}">
    		   @endif
    		@else 
    		  <a href="{{route('index')}}"><img src="{{asset('image/logo.png')}}"></a>
    		@endauth
    	</div>
    	<div class="user">
               @auth
                    <a href="#" class="userTv"><img src="{{asset('image/user_logo.png')}}">{{Auth::user()['name']}}</a>
                    <img src="{{asset('image/logout.png')}}" title="{{ __('common.Logout') }}" onclick="logout('logout-form')"> 
        	        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="mcss-hide">
                        @csrf
                    </form>
                @else
                    <a href="{{route('customLogin')}}" class="login">{{ __('common.Login') }}</a>
                @endauth
        </div>
</div>