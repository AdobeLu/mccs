<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/jquery-3.4.1.min.js')}}"></script>
    <script src="{{ asset('js/bootstrap-4.4.1.min.js')}}"></script>
    <link rel="shortcut icon" href="{{ asset('favicon.ico') }}">
    <script src="{{ asset('js/md5.min.js')}}"></script>
    <script src="{{ asset('js/web.js') }}"></script>
 	<script src="{{ asset('js/formValidation.js')}}"></script>
 	<script src="{{ asset('js/mccs-auth.js') }}"></script>
    <!-- Fonts -->

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{ asset('css/appExtension.css') }}" rel="stylesheet">
    <link href="{{ asset('css/mccs.css') }}" rel="stylesheet">
</head>
<body style="background-color: white">
    <div id="app">
        <div class="top-container">
    @include('top')
</div>

        <main class="py-4">
            @yield('content')
        </main>
    </div>
</body>
</html>
