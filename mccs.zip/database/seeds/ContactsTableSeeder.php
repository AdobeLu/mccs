<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ContactsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('contacts')->insert([
            'name'  => '陆利刚',
            'email' => 'lu_ligang@dahuatech.com',
            'phone' => '18969963087',
            'status' => 0,
        ]);
        DB::table('contacts')->insert([
            'name'  => '刘晓虎',
            'email' => 'liu_xiaohu@dahuatech.com',
            'phone' => '18106513408',
            'status' => 0,
        ]);
    }
}
