<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('', 'WelcomeController@index')->name('index');
//Route::any('/test', 'WelcomeController@test')->name('test');

Auth::routes(['verify'=>true]);

Route::group([], function() {
    Route::get('/home', 'HomeController@index')->name('home')->middleware('throttle:60');
    Route::post('/user/destory', 'HomeController@destroy')->name('user.destroy')->middleware('checkPermission');;
    Route::post('/user/mutiDestroy', 'HomeController@mutiDestroy')->name('user.mutiDestroy')->middleware('checkPermission');;
});

Route::group([], function() {
    Route::post('/user/read/{id}', 'Auth\RegisterController@read')->name('user.read');
    Route::post('/add','Auth\RegisterController@store')->name('add')->middleware('dataIntegrity');
    Route::post('/edit/{id}','Auth\RegisterController@update')->name('user.update')->middleware('dataIntegrity');
});

Route::group([], function() {
    Route::post('/customLogin', 'Auth\LoginController@customLogin')->name('customLogin');
    Route::get('/customLogin', 'Auth\LoginController@myLoginForm')->name('login');
    Route::get('/cp', '\App\LoginController@captcha');
});

Route::group(['middleware' => 'dataIntegrity'], function () {
    Route::post('/logout', 'Auth\LoginController@logout')->name('logout');
});

Route::group(['middleware' => 'auth'], function () {
    Route::post('/web/upload', 'Web\WebUploadController@upload')->name('web.upload');
    Route::get('/web', 'Web\WebUploadController@index')->name('web');
    Route::post('/web/delete', 'Web\WebUploadController@delete')->name('web.delete');
    Route::post('/web/delete-more', 'Web\WebUploadController@deleteMore')->name('web.delete.more');
    Route::post('/web/new', 'Web\WebUploadController@create')->name('web.new');
    Route::post('/web/name', 'Web\WebUploadController@changeName')->name('web.name');
});
//Route::get('/web/qrcode', 'Web\WebUploadController@qrCode')->name('web.qrcode');
Route::get('/w/{link}', 'Web\WebUploadController@link')->name('web.link')/* ->where('link','[a-zA-Z0-9]{6}') */;
//Route::get('/web/download/{id}', 'Web\WebUploadController@download')->name('web.download');

