<?php
namespace App\Util;

use Illuminate\Support\Facades\Log;

class SignVerify
{
    public static function verifySign($secret, $data) {
        // 验证参数中是否有签名
        if (!isset($data['sign']) || !$data['sign']) {
           return 3;
        }
        if (!isset($data['timestamp']) || !$data['timestamp']) {
            return 2;
        }
        //Log::info( ceil(microtime(true)*1000) - $data['timestamp']);
        if (ceil(microtime(true)*1000) - $data['timestamp'] > 600000) {
            Log::info("数据传输超出: ".ceil(microtime(true)*1000) - $data['timestamp']);
           return 4;
        }
        $sign = $data['sign'];
        unset($data['sign']);
        ksort($data);
        $params = http_build_query($data,null,"&",PHP_QUERY_RFC3986);
       // $params = str_replace('+', '%20', $params);
        /* $parmas = "";
        foreach ($data as $key => $value) {
            if(is_array($value)){
                for($i =0 ; $i < count($value);$i++){
                    $parmas .=urlencode($key."[".$i."]")."=".urlencode($value[$i])."&";
                }
            }else{
                $parmas .=urlencode($key)."=".urlencode($value)."&";
            }
        } */
        //Log::info($params ."&". $secret);
        $sign2 = md5($params ."&". $secret);
        //Log::info($sign2."  ".$sign);
        if ($sign == $sign2) {
            return 1;
        } else {
            return 0;
        }
    }
}

