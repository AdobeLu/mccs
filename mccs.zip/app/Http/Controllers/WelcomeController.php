<?php
namespace App\Http\Controllers;

use App\Model\Contact;
use Illuminate\Http\Request;


class WelcomeController extends Controller
{
    public function index()
    {
        $contacts = null;
        
        try {
            $contacts = Contact::query()
            ->select('name','phone','email')
            ->where('status', '=',0)
            ->orderBy('id')
            ->limit(2)
            ->get();
        } catch (\Exception $e) {
        
        }
        
        $data = [
            'contacts' => $contacts == null ? array() :$contacts->toArray(),
        ];
        return view('welcome',$data);
    }
}

