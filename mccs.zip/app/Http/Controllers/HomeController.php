<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        if ($this->hasPermisision()) {
            $user = User::where('accountType','!=','admin')->paginate(20);
            return view('home', compact('user'));
        }else {
            return redirect('/');
        }
    }
    
    public function destroy(Request $request)
    {
        for($x=0;$x<count($request->get('keys'));$x++)
        {
            echo json_encode($request->get('keys'));
            $contact = User::find($request->get('keys')[$x]);
            $contact->delete();
        }
        
        return redirect('home')->with('success', 'User deleted!');
    }
    
    public function mutiDestroy(Request $request) {
        for($x=0;$x<count($request->get('sub'));$x++)
        {
            $contact = User::find($request->get('sub')[$x]);
            $contact->delete();
        }
        return redirect('home')->with('success', __("user.userDeleteSuccess"));
    }
    
    private function hasPermisision() {
        return Auth::user()->accountType == 'admin';
    }
}
