<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class RegisterUserPost extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => ['required', 'unique:users',
                function ($attribute, $value, $fail) {
                    $result = preg_match('/^([A-Za-z0-9@_.]*){1,64}$/', $value);
                    if ($result != 1) {
                        $fail(__("validation.invalidCharter"));
                        return;
                    }
                }
            ],
            'password' => ['confirmed',
                function ($attribute, $value, $fail) {
                    $result = preg_match('/^(\w*(?=\w*\d)(?=\w*[A-Za-z])\w*){8,32}$/', $value);
                    if ($result != 1) {
                        $fail(__("passwords.password_requirements"));
                        return;
                    }
                }]
           ];
    }
}
