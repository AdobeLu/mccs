<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;
use Illuminate\Support\Facades\Log;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        //
        \App\Console\Commands\WebResorceDelete::class,
        \App\Console\Commands\BackupDatabase::class,
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        // $schedule->command('inspire')
        //          ->hourly();
        $schedule->command('WebHtml:delete')->daily()->runInBackground()->before(function () {
            Log::channel('key')->info("静态web删除开始");
        })
        ->after(function () {
            Log::channel('key')->info("静态web删除结束");
        });
        $schedule->command('db:backup')->wednesdays()->at('2:00')->runInBackground()->before(function () {
            Log::channel('key')->info("数据库备份开始");
        })
        ->after(function () {
            Log::channel('key')->info("数据库备份结束");
        });
        
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands() 
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
    
    protected function scheduleTimezone()
    {
        return "Asia/Shanghai";
    }
}


