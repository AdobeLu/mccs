<?php
namespace App\Model\Web;

use App\Model\Base\BaseModel;
use Illuminate\Support\Facades\Storage;

class StaticHtml extends BaseModel
{
    protected $table = 'static_htmls';
    protected $fillable = ['name', 'origin_name', 'real_path', 'status', 'user_id','link','zip_path','upload_times'];
    
    public static function deleteResource(){
        $ret = StaticHtml::query()->where("status", "=",1)->get()->toArray();
        if($ret){
            foreach($ret as $item){
                if($item['zip_path']){
                    if(Storage::disk('uploads')->exists($item['zip_path'])){
                        Storage::disk('uploads')->delete($item['zip_path']);
                    }
                    if($item['real_path']){
                        Storage::disk('uploads')->deleteDirectory($item['real_path']);
                    }
                }
                
                StaticHtml::find($item['id'])->delete();
            }
        }
    }
}

