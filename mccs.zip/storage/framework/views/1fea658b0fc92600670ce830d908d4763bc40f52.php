<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'MCCS')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
	<script src="<?php echo e(asset('js/jsEncrypt.js')); ?>" defer></script>
	<script src="<?php echo e(asset('js/md5.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/formValidation.js')); ?>"></script>
	<script src="<?php echo e(asset('js/mccs-auth.js')); ?>" defer></script>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
<!--     <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet"> -->

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/appExtension.css')); ?>" rel="stylesheet">
</head>
<body class="bg-dark">
<div>
<div class="row justify-content-center">
<img src="../image/logo.png" class="img-fluid justify-content-center" style="margin-top: 202px" alt="Responsive image">
</div>
    <div class="row justify-content-center" style="margin-top: 52px;">
        <div class="col-12">
        	<div class="col-sm-9 col-md-7 col-lg-5 col-xl-4 m-auto" style="background-image: url(../image/login_pic_bg.png);height: 605px">
                <div class="col-sm-12 col-md-10 col-lg-8 col-xl-8 card m-auto">
                    <div class="card-whiteHeader"><?php echo e(__('Login')); ?></div>
    
                    <div class="card-body">
                        <form id="loginForm" method="POST" action="<?php echo e(route('customLogin')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type='hidden' id="token" name="token" value="<?php echo e($token); ?>">
                            <div class="form-group row">
                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> onlyNumAlphaSymble" name="name" value="<?php echo e(old('name')); ?>" placeholder="<?php echo e(__('auth.user_placeholder')); ?>" maxlength="64" required autocomplete="name" autofocus>
    
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
<!--      <a class="nav-link text-dark" href="<?php echo e(route('register')); ?>">注册</a> -->
                            <div class="form-group row row-margin-top">
                                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="background-color:#efefef" placeholder="<?php echo e(__('auth.password_placeholder')); ?>" readonly="true" name="password" required autocomplete="off">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <?php if($attempts > 0): ?> 
                            <div class="form-group row row-margin-top">
								<input id="verCode" class="form-control col-4 <?php $__errorArgs = ['verCode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="verCode" placeholder="<?php echo e(__('common.verCode')); ?>" required><img id="verImg" src="<?php echo e(captcha_src()); ?>" style="margin-left: 5px">
                            	<?php $__errorArgs = ['verCode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <?php endif; ?>
                            <div class="form-group row row-margin-top">
                                <button id="loginBtn" disabled type="submit" class="btn btn-primary" style="width: 100%;background-color:#007aff;height:44px">
                                    <?php echo e(__('Login')); ?>

                                </button>
                            </div>
                            <input type="hidden" id="timestamp" name="timestamp">
                			<input type="hidden" id="sign" name="sign">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
<script>
window.addEventListener('DOMContentLoaded', function() {
	$('#verImg').on('click', function(){
		$('#verImg').attr('src', "<?php echo e(url('captcha/default')); ?>");
	});
	$("#password").on("focus", function () {
	    $(this).attr("readonly", false)
	})
	$('#loginForm').submit(function(){ 
		var encrypt = new JSEncrypt();
		encrypt.setPublicKey('MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCmx13ZZo3r4yz7C8tI2kxpuzpKzJkxjgLB5hQqVcrFgGyjwokA6eXF3khJiTMlvtnVGKU+oA9bj63scV3XSLnqGj22EJerS8jqZ4goSzAMiRnuYdmJ67BSDkUXVmMiFULoaoPwH3rQK4QRK24xZK/3BdWGuY0og8r7zWQm51yY3QIDAQAB');
		var password = encrypt.encrypt($('#password').val());
		$('#password').val(password);
		var timestamp = Date.parse(new Date());
		$('#timestamp').val(timestamp);
		var form = document.getElementById('loginForm');
		$('#sign').val(signData(form,timestamp));
		return true;
	});
	$('#name').on('input propertychange', function(){
		if($(this).val().trim() != '' && $('#password').val().trim() != ''){
			$('#loginBtn').removeAttr('disabled');
		}else {
			$('#loginBtn').attr('disabled',true);
		}
		if($(this).val().length > 64){
			$(this).val( $(this).val().substring(0,64) );
        }
	});

	$('#password').on('input propertychange', function(){
		if($(this).val().trim() != '' && $('#name').val().trim() != ''){
			$('#loginBtn').removeAttr('disabled');
		}else {
			$('#loginBtn').attr('disabled',true);
		}
		if($(this).val().length > 32){
			$(this).val( $(this).val().substring(0,32) );
        }
	});
});
</script>
</html>
<?php /**PATH /Users/luligang/Documents/svn/code/AppDistribution/resources/views/auth/login.blade.php ENDPATH**/ ?>