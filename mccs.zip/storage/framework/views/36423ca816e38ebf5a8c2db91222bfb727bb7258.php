<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
   <!--  <meta name="viewport" content="width=device-width, initial-scale=1"> -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(__('webs.web_static_deployment')); ?></title>
    <link href="<?php echo e(asset('css/mccs.css')); ?>" rel="stylesheet">
    <link rel="shortcut icon" href="<?php echo e(asset('image/favicon.png')); ?>">
    <style type="text/css">
         input[type="checkbox"] {
            -webkit-appearance: none; 
            background: url("<?php echo e(asset('/image/uncheck.png')); ?>") no-repeat;
            width: 16px;
            height: 16px;
            vertical-align: middle;
            outline: none;
        }
         input[type="checkbox"]:checked {
            -webkit-appearance: none;
            background: url("<?php echo e(asset('/image/checked.png')); ?>") no-repeat;
            width: 16px;
            height: 16px;
            vertical-align: middle;
            outline: none;
        }
   </style>
</head>
<body>
<div class="top-container">
    <?php echo $__env->make('top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<div class="web-content">
    <div>
    	<div class="web-opt" onclick="createWeb('add-form')">
        	<img src="<?php echo e(asset('image/add.png')); ?>" class="icon"><span class="opt-txt"><?php echo e(__('webs.new_web')); ?></span>
        </div>
        	<form id="add-form" action="<?php echo e(route('web.new')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
    	<div class="web-opt delete" onclick="event.preventDefault();showDialog(true,'delete-form-more',null);">
    	     <img src="<?php echo e(asset('image/delete_d.png')); ?>" class="icon" id="delete-more-icon"><span class="opt-txt" style="color:#9e9e9e" id="delete-more-txt"><?php echo e(__('webs.delete_web')); ?></span>
    	</div>
    	<form id="delete-form-more" action="<?php echo e(route('web.delete.more')); ?>" method="POST" style="display: none;">
    	   <?php echo csrf_field(); ?>
    	   <input type="hidden" id='ids' value="" name="ids">
    	</form>
    	<div style="clear:both"></div>
    </div>
    
    <hr>
    <?php if(empty($data)): ?>
        <div class="web-no-data" onclick="createWeb('add-form')">
        	<div style="margin-bottom:54px"><img  src="<?php echo e(asset('image/no_web_item.png')); ?>" /></div>
        	<span><?php echo e(__('webs.no_web_item')); ?></span>
        </div>
    <?php else: ?>
        <table>
    	    <tr>
    	    	<th class="t1"><input type="checkbox" id="check-all" name="check-all" onclick="swapCheck()"></th>
    	        <th class="t2"><?php echo e(__('webs.web_name')); ?></th> 
    	        <th class="t4"><?php echo e(__('webs.web_link')); ?></th> 
    	        <th class="t4"><?php echo e(__('webs.web_html_name')); ?></th>
    	        <th class="t3"><?php echo e(__('webs.web_opt')); ?></th> 
    	    </tr>
    	    <tr style="height: 10px">
    	        <td colspan="5"><hr></td>
    	    </tr>
    	    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
        	    	<td class="t1"><input type="checkbox" name="p" value="<?php echo e($item['id']); ?>" onclick="checkChange(this)"></td>
        	        <td class="t2 singleline">
        	           <form action="<?php echo e(route('web.name')); ?>" method="post" id="form-name-<?php echo e($item['id']); ?>" name="form-name-<?php echo e($item['id']); ?>" class="valign-middle-container" style="display: <?php echo e(isset($c_id) && $c_id== $item['id'] ? '' : 'none'); ?>">
	                      
	                      <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
	                      <?php echo csrf_field(); ?>
	                      <input type="text" name="name" id="name-<?php echo e($item['id']); ?>" value = "<?php echo e(isset($c_id) && $c_id== $item['id'] ? (old('name') ? old('name') : $item['name']) : $item['name']); ?>" class="input-name">
	                      <img  src="<?php echo e(asset('image/web_ok.png')); ?>" onclick="changeName(<?php echo e($item['id']); ?>,'normal-<?php echo e($item['id']); ?>','<?php echo e(route('web.name')); ?>')"/>
	                      <!--  <img  src="<?php echo e(asset('image/web_ok.png')); ?>" onclick="document.getElementById('form-name-<?php echo e($item['id']); ?>').submit();"/>-->
	                      <img  src="<?php echo e(asset('image/web_cancel.png')); ?>" onclick="changeMode('normal-<?php echo e($item['id']); ?>','form-name-<?php echo e($item['id']); ?>','name-<?php echo e($item['id']); ?>')"/>
        	            </form>
        	            <div id="normal-<?php echo e($item['id']); ?>" style="display: <?php echo e(isset($c_id) && $c_id== $item['id'] ? 'none' : 'block'); ?>"><?php echo e($item['name']); ?></div>
        	        </td>
        	        <td class="t4">
        	              <span class="singleline u-name"><a href="<?php echo e(route('web.link', $item['link'])); ?>" target="_blank"><?php echo e(route('web.link', $item['link'])); ?></a></span>
        	              <a href="<?php echo e(route('web.link', $item['link'])); ?>"  class="qr_code" onclick="event.preventDefault();"><img src="<?php echo e(asset('image/qr_code.png')); ?>" width="24px" height="24px"/></a>
                     </td>
        	        <td class="t4">
        	           <form method="POST" enctype="multipart/form-data" id="file-upload-<?php echo e($item['id']); ?>" action="<?php echo e(route('web.upload')); ?>" style="display:hidden">
        	               <?php echo csrf_field(); ?>
        	               <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
        	               <input type="file" name="file-html" class="file-input" id ="file-<?php echo e($item['id']); ?>" onchange="fileSelect(<?php echo e($item['id']); ?>,'file-<?php echo e($item['id']); ?>','<?php echo e(route('web.upload')); ?>')"> 
        	           </form>
        	           <?php if($item['origin_name'] != null): ?>
            	           <a href="<?php echo e(asset('html/'.$item['zip_path'])); ?>" download="<?php echo e($item['origin_name']); ?>">
                	           <img src="<?php echo e(asset('image/zip.png')); ?>">
                	           <span class="singleline u-name"  style="padding-top:5px;"><?php echo e($item['origin_name']); ?></span>
                	       </a>
                	       <span class="btn-upload btn-upload-re" onclick="document.getElementById('file-<?php echo e($item['id']); ?>').click();"><?php echo e(__('webs.web_reupload')); ?></span>
        	          <?php else: ?>
        	               <span class="btn-upload" onclick="document.getElementById('file-<?php echo e($item['id']); ?>').click();"><?php echo e(__('webs.web_upload')); ?></span>
        	          <?php endif; ?>
        	        </td>
        	        <td class="t3">
        	             <span class="opt" onclick="changeMode('form-name-<?php echo e($item['id']); ?>','normal-<?php echo e($item['id']); ?>')"><?php echo e(__('webs.web_modify')); ?></span>
        	             <span class="opt" onclick="showDialog(false,'delete-form-<?php echo e($item['id']); ?>','<?php echo e($item['name']); ?>');"><?php echo e(__('webs.delete_web')); ?></span>
        	             <form id="delete-form-<?php echo e($item['id']); ?>" action="<?php echo e(route('web.delete')); ?>" method="POST" style="display:none;">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                         </form>
        	         </td>
        	         
        	    </tr>
    	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr style="height: 10px">
            <td colspan="5"><hr></td>
            </tr>
        </table>
        <div class="nav-right">
           <a class="nav <?php echo e($prev_page_url ? '' : 'nav-disable'); ?>" href="<?php echo e($prev_page_url); ?>" onclick="<?php echo e($prev_page_url ? '' : 'event.preventDefault();'); ?>">&lt;</a>
           
           <?php for($i = ($current_page-5 > 0 ? $current_page-5 : 1); $i < $current_page; $i++): ?>
           <a class="nav" href="<?php echo e(URL::current()); ?>?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
           <?php endfor; ?>
           <a class="nav nav-current"
               href="<?php echo e(URL::current()); ?>?page=<?php echo e($current_page); ?>" onclick="event.preventDefault();"><?php echo e($current_page); ?></a>
           <?php for($i = $current_page + 1; $i <= ($current_page + 5 > $last_page ? $last_page : $current_page + 5); $i++): ?>
            <a class="nav" href="<?php echo e(URL::current()); ?>?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
           <?php endfor; ?>

           <a class="nav <?php echo e($next_page_url ? '' : 'nav-disable'); ?>" href="<?php echo e($next_page_url); ?>" onclick="<?php echo e($next_page_url ? '' : 'event.preventDefault();'); ?>">&gt;</a>
        </div>
    <?php endif; ?> 
    
</div>
<div class="dialog" id="dialog">
   <div class="dialogContent">
       <div style="padding-top:20px;font-size:1.5em;">
          <span id="dialgTitle" class="two-lines"></span>
       </div>
       <div style="padding-top:10px;font-size:1.2em;"><?php echo e(__('webs.web_delete_warn')); ?></div>
       <div style="position:absolute;bottom:40px;right:40px">
           <button id="cancel"><?php echo e(__('webs.web_cacnel')); ?></button>
           <button id="ok"><?php echo e(__('webs.web_ok')); ?></button>
       </div>
   </div>
</div>
<div id="msg-container" style="display:none;">
  <span style="line-height:80px" id="msg-tip"></span>
</div>
<div id="loading">
    <div class="loadingCenter"></div>
</div>
<script src="<?php echo e(asset('js/jquery-1.8.3.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/md5.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.qrcode.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/web.js')); ?>"></script>
<script type="text/javascript">
     $.getScript("<?php echo e(asset('js/web.js')); ?>", function() {
    	 initVar("<?php echo e(asset('')); ?>","<?php echo e(__('webs.web_delete_no_choose')); ?>",
    	    	,"<?php echo e(__('webs.web_delete_item')); ?>","<?php echo e(__('webs.web_mimetype_fail')); ?>","<?php echo e(__('webs.web_name_limit')); ?>");
    });
</script>
<?php if(session('message') != null): ?>
<script type="text/javascript">
   showMsg('<?php echo e(session('message')); ?>');
</script>     
<?php endif; ?>
</body>
</html>
<?php /**PATH /Users/luligang/Documents/svn/code/AppDistribution/resources/views/web.blade.php ENDPATH**/ ?>