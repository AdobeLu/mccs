<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title><?php echo e(config('app.name', 'MCCS')); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('image/favicon.png')); ?>">
    <link href="<?php echo e(asset('css/mccs.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('js/jquery-2.1.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/banner.js')); ?>"></script>
    <script src="<?php echo e(asset('js/md5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/web.js')); ?>"></script>
</head>
<body>
<div class="top-bg"></div>
<?php echo $__env->make('top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="banner">
    <div class="b-img">
      	<a href="" style="background:url(<?php echo e(asset('image/banner01.png')); ?>) center no-repeat;"></a>
      	<a href="" style="background:url(<?php echo e(asset('image/banner02.png')); ?>) center no-repeat;"></a>
    </div>
    <div class="b-list"></div>
</div>
<div class="func">
    <?php $__currentLoopData = config('mccs.welcome.funcs'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $func): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="funcItem">
    		<div class="funcCenter">
    			<a href="<?php echo e(route($func['route_name'])); ?>"  onclick="<?php echo e($func['route_name'] == 'index' ? 'event.preventDefault();' :''); ?>">
    				<img src="<?php echo e(asset($func['img'])); ?>" class="imgLogo" />
    				<span class="funcTxt">
    				     <?php echo e($func['name']); ?>

    			    </span>
    			</a>
    		</div>
    	</div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div style="text-align: center;clear: left;margin-top: 84px">
	<div style="font-size:2.5em">
		<?php echo e(config('mccs.welcome.func_online.name')); ?>

	</div>
	<div style="margin: 15px auto;font-size: 1em">
		<?php echo e(config('mccs.welcome.func_online.desc')); ?>

	</div>
	<div style="margin: 26px auto">
		<a href="#" class="more" onclick="event.preventDefault();">
		  <?php echo e(config('mccs.welcome.func_online.more')); ?>

	   </a>
	</div>
</div>
<div class="pop">
    <?php $__currentLoopData = config('mccs.welcome.pops'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="popItem">
    		<div class="funcCenter">
    			<a href="<?php echo e(route($pop['route_name'])); ?>" onclick="<?php echo e($pop['route_name'] == 'index' ? 'event.preventDefault();' :''); ?>">
    				<img src="<?php echo e(asset($pop['img'])); ?>" class="popImg" />
    				<span class="popTxt">
    				     <?php echo e($pop['name']); ?>

    			    </span>
    			    <span class="popDesc">
    			    	<?php echo e($pop['desc']); ?>

    			    </span>
    			</a>
    		</div>
        </div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="popLine"></div>
</div>
<div style="clear: both;"></div>
<div class="pub" style="background-image:url(<?php echo e(asset('image/process_bg.png')); ?>);">
	<div class="pubTitle"><?php echo e(config('mccs.welcome.pubs_title')); ?></div>
	<div class="pubC">
	    <?php $__currentLoopData = config('mccs.welcome.pubs'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="pubItem">
    			<div style="margin: 0 auto;">
    				<img src="<?php echo e(asset($pub['img'])); ?>" class="pubImg" />
    				<div class="pubTxt">
    				    <?php echo e($pub['name']); ?>

    			    </div>
    			</div>
    		</div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<div  class="footer">
	<div class="p-m-c">
		 <div><?php echo e(config('mccs.welcome.contacts_txt.title')); ?></div>
		 <?php if(empty($contacts)): ?>
		    <?php $__currentLoopData = config('mccs.welcome.contacts'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		   <div class="contactItem">
        			<div><span><?php echo e(config('mccs.welcome.contacts_txt.name_label')); ?></span><span><?php echo e($contact['name']); ?></span></div>
        			<div style="margin-top: 12px;margin-bottom: 12px"><span><?php echo e(config('mccs.welcome.contacts_txt.email_label')); ?></span><span><?php echo e($contact['email']); ?></span></div>
        			<div><span><?php echo e(config('mccs.welcome.contacts_txt.phone_label')); ?></span><span><?php echo e($contact['phone']); ?></span></div>
    		   </div>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  <?php else: ?>
		     <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		   <div class="contactItem">
        			<div><span><?php echo e(config('mccs.welcome.contacts_txt.name_label')); ?></span><span><?php echo e($contact['name']); ?></span></div>
        			<div style="margin-top: 12px;margin-bottom: 12px"><span><?php echo e(config('mccs.welcome.contacts_txt.email_label')); ?></span><span><?php echo e($contact['email']); ?></span></div>
        			<div><span><?php echo e(config('mccs.welcome.contacts_txt.phone_label')); ?></span><span><?php echo e($contact['phone']); ?></span></div>
    		   </div>
		     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  <?php endif; ?>
		 
	</div>

	<div class="beian">
            &copy;<?php echo e(date('Y').config('mccs.welcome.company.name')); ?><a href="http://www.beian.miit.gov.cn/" 
            target="_blank" style="color: #5D6D8B">&nbsp;&nbsp;<?php echo e(config('mccs.welcome.company.icp')); ?></a>
            <a href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=<?php echo e(config('mccs.welcome.company.beian')); ?>" style="margin-left:25px;color: #5D6D8B" id="safety" target="_blank"><?php echo e(config('mccs.welcome.company.beian_address')); ?></a>
	</div>
</div>
</body>
</html>
<?php /**PATH D:\www\AppDistribution\resources\views/welcome.blade.php ENDPATH**/ ?>