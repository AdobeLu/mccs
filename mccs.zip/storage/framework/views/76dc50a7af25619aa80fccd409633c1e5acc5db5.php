<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <link rel="shortcut icon" href="<?php echo e(asset('image/favicon.png')); ?>">
    <script src="<?php echo e(asset('js/md5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/web.js')); ?>"></script>
 	<script src="<?php echo e(asset('js/formValidation.js')); ?>"></script>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/appExtension.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/mccs.css')); ?>" rel="stylesheet">
</head>
<body style="background-color: white">
    <div id="app">
        <div class="top-container">
    <?php echo $__env->make('top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
<?php /**PATH /Users/luligang/Documents/svn/code/AppDistribution/resources/views/layouts/app.blade.php ENDPATH**/ ?>