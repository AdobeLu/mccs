<div class="top">
    	<div class="logo">
    		<a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(asset('image/logo.png')); ?>"></a>
    	</div>
    	<div class="user">
               <?php if(auth()->guard()->check()): ?>
                    <img src="<?php echo e(asset('image/user_logo.png')); ?>" style="display:inline-block;vertival-align:middle;"> 
                   
                    <ul class="drop-nav">
                        <li class="drop-down">
            	            <a href="" class="userTv" ><?php echo e(Auth::user()['name']); ?></a>
                	        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                            <ul class="drop-down-content">
                                <!-- <li><a href="<?php echo e(route('web')); ?>">静态部署</a></li> -->
                                <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();logout('logout-form')"><?php echo e(__('common.Logout')); ?></a></li>
                            </ul>
                        </li>
                        
                    </ul>
                <?php else: ?>
                    <a href="<?php echo e(route('customLogin')); ?>" class="login"><?php echo e(__('common.Login')); ?></a>
                <?php endif; ?>
        </div>
</div><?php /**PATH /Users/luligang/Documents/svn/code/AppDistribution/resources/views/top.blade.php ENDPATH**/ ?>