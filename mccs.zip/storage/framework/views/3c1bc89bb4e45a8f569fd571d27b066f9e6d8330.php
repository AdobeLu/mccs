<?php $__env->startSection('content'); ?>

<?php if('<?php echo e(count($appinfo)); ?>' == 0): ?>
    <script src="<?php echo e(asset('js/plugins/canvas-to-blob.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/sortable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/purify.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/fileinput.js')); ?>"></script>
    <script src="<?php echo e(asset('js/fa.js')); ?>"></script>
    

    <!-- Styles -->
    <link href="<?php echo e(asset('css/fileinput.min.css')); ?>" rel="stylesheet">
<div class='container w-50'>
    <div class="file-loading">
    	<input id="input-b7" name="input-b7[]" multiple type="file" class="file" data-allowed-file-extensions='["ipa", "apk"]'>
	</div>
	<div class="text-center">
		在这里上传您的第一个应用吧~
	</div>
</div>
<script>
	$("#input-b7").fileinput({
        uploadUrl: "/file-upload-batch/1",
        uploadAsync: false,
        minFileCount: 1,
        maxFileCount: 1,
        showBrowse: false,
        showCaption: false,
        autoReplace: true,
        showUpload: false,
        showRemove: false,
        overwriteInitial: false,
        initialPreviewAsData: true, // 默认为数据
        initialPreviewFileType: 'image', // 默认为`image`，在下面的配置中可以覆盖
        initialPreviewConfig: [
            {caption: "Business 1", filename: "Business-1.jpg", size: 762980, url: "/site/file-delete", key: 11},
            {previewAsData: false, size: 823782, caption: "Business 2", filename: "Business-2.jpg", url: "/site/file-delete", key: 13}, 
            {caption: "Lorem Ipsum", filename: "LoremIpsum.txt", type: "text", size: 1430, url: "/site/file-delete", key: 12}, 
            {type: "pdf", size: 8000, caption: "PDF Sample", filename: "PDF-Sample.pdf", url: "/file-upload-batch/2", key: 14}, 
            {type: "video", size: 375000, filetype: "video/mp4", caption: "Krajee Sample", filename: "KrajeeSample.mp4", url: "/file-upload-batch/2", key: 15},  
        ],
        uploadExtraData: {
            img_key: "1000",
            img_keywords: "happy, nature",
        }
    }).on('filesorted', function(e, params) {
        console.log('File sorted params', params);
    }).on('fileuploaded', function(e, params) {
        console.log('File uploaded params', params);
    });
</script>

<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/luligang/Documents/svn/code/AppDistribution/resources/views/appinfo/appinfo.blade.php ENDPATH**/ ?>