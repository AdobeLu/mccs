<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>MCCS移动能力中心系统</title>
    <link href="<?php echo e(asset('css/mccs.css')); ?>" rel="stylesheet">
    <style type="text/css">
         input[type="checkbox"] {
            -webkit-appearance: none; 
            background: url("<?php echo e(asset('/image/uncheck.png')); ?>") no-repeat;
            width: 16px;
            height: 16px;
            vertical-align: middle;
            outline: none;
        }
         input[type="checkbox"]:checked {
            -webkit-appearance: none;  /*清除复选框默认样式*/
            background: url("<?php echo e(asset('/image/checked.png')); ?>") no-repeat;
            width: 16px;
            height: 16px;
            vertical-align: middle;
            outline: none;
        }
   </style>
</head>
<body>
<div class="top-container">
    <?php echo $__env->make('top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<div class="web-content">
    <div>
    	<div class="web-opt" onclick="event.preventDefault();document.getElementById('add-form').submit();">
        	<img src="<?php echo e(asset('image/add.png')); ?>" class="icon"><span class="opt-txt">新建项目</span>
        </div>
        	<form id="add-form" action="<?php echo e(route('web.new')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
    	<div class="web-opt delete" onclick="event.preventDefault();showDialog(true,'delete-form-more',null);">
    	     <img src="<?php echo e(asset('image/delete_d.png')); ?>" class="icon" id="delete-more-icon"><span class="opt-txt">删除</span>
    	</div>
    	<form id="delete-form-more" action="<?php echo e(route('web.delete.more')); ?>" method="POST" style="display: none;">
    	   <?php echo csrf_field(); ?>
    	   <input type="hidden" id='ids' value="" name="ids">
    	</form>
    	<div style="clear:both"></div>
    </div>
    
    <hr>
    <?php if(empty($data)): ?>
        <div class="web-no-data">
        	<div><img  src="<?php echo e(asset('image/no_web_item.png')); ?>" /></div>
        	<span>还没有项目，点击创建一个新项目吧~</span>
        </div>
    <?php else: ?>
        <table>
    	    <tr>
    	    	<th class="t1"><input type="checkbox" id="check-all" name="check-all" onclick="swapCheck()"></th>
    	        <th class="t2">项目名称</th> 
    	        <th class="t4">产品链接</th> 
    	        <th class="t4">上传html文件包</th>
    	        <th class="t3">操作</th> 
    	    </tr>
    	    <tr style="height: 10px"><td colspan="5"><hr></td></tr>
    	    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
        	    	<td class="t1"><input type="checkbox" name="p" value="<?php echo e($item['id']); ?>" onclick="checkChange(this)"></td>
        	        <td class="t2 singleline">
        	           <form action="<?php echo e(route('web.name')); ?>" method="post" id="form-name-<?php echo e($item['id']); ?>" name="form-name-<?php echo e($item['id']); ?>" class="valign-middle-container" style="display: <?php echo e(isset($c_id) && $c_id== $item['id'] ? '' : 'none'); ?>">
	                      <?php echo csrf_field(); ?>
	                      <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
	                      <input type="text" name="name" value = "<?php echo e($item['name']); ?>" class="input-name">
	                      <img  src="<?php echo e(asset('image/web_ok.png')); ?>" onclick="document.getElementById('form-name-<?php echo e($item['id']); ?>').submit();"/>
	                      <img  src="<?php echo e(asset('image/web_cancel.png')); ?>" onclick="changeMode('normal-<?php echo e($item['id']); ?>','form-name-<?php echo e($item['id']); ?>')"/>
        	            </form>
        	            <div id="normal-<?php echo e($item['id']); ?>" style="display: <?php echo e(isset($c_id) && $c_id== $item['id'] ? 'none' : ''); ?>"><?php echo e($item['name']); ?></div>
        	        </td>
        	        <td class="t4">
        	              <span class="singleline u-name"><a href="<?php echo e(route('web.link', $item['link'])); ?>" target="_blank"><?php echo e(route('web.link', $item['link'])); ?></a></span>
        	              <a href="<?php echo e(route('web.link', $item['link'])); ?>"  class="qr_code" onclick="event.preventDefault();"><img src="<?php echo e(route('web.qrcode',['link'=>route('web.link', $item['link'])])); ?>" width="24px" height="24px"/></a>
                     </td>
        	        <td class="t4">
        	           <form method="POST" enctype="multipart/form-data" id="file-upload-<?php echo e($item['id']); ?>" action="<?php echo e(route('web.upload')); ?>" style="display:hidden">
        	               <?php echo csrf_field(); ?>
        	               <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
        	               <input type="file" name="file-html" class="file-input" id ="file-<?php echo e($item['id']); ?>" onchange="fileSelect(<?php echo e($item['id']); ?>,'file-<?php echo e($item['id']); ?>','<?php echo e(route('web.upload')); ?>')"> 
        	           </form>
        	           <?php if($item['origin_name'] != null): ?>
            	           <a href="<?php echo e(asset('html/'.$item['zip_path'])); ?>" download="<?php echo e($item['origin_name']); ?>">
                	           <img src="<?php echo e(asset('image/zip.png')); ?>">
                	           <span class="singleline u-name"  style="padding-top:5px;"><?php echo e($item['origin_name']); ?></span>
                	       </a>
                	       <span class="btn-upload btn-upload-re" onclick="document.getElementById('file-<?php echo e($item['id']); ?>').click();">重新上传 </span>
        	          <?php else: ?>
        	               <span class="btn-upload" onclick="document.getElementById('file-<?php echo e($item['id']); ?>').click();">上传 </span>
        	          <?php endif; ?>
        	        </td>
        	        <td class="t3">
        	             <span class="opt" onclick="changeMode('form-name-<?php echo e($item['id']); ?>','normal-<?php echo e($item['id']); ?>')">修改</span>
        	             <span class="opt" onclick="showDialog(false,'delete-form-<?php echo e($item['id']); ?>','<?php echo e($item['name']); ?>');">删除</span>
        	             <form id="delete-form-<?php echo e($item['id']); ?>" action="<?php echo e(route('web.delete')); ?>" method="POST" style="display:none;">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                         </form>
        	         </td>
        	         
        	    </tr>
    	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <tr style="height: 10px"><td colspan="5"><hr></td></tr>
        </table>
        <div class="nav-right">
           <a class="nav <?php echo e($prev_page_url ? '' : 'nav-disable'); ?>" href="<?php echo e($prev_page_url); ?>" onclick="<?php echo e($prev_page_url ? '' : 'event.preventDefault();'); ?>">&lt;</a>
           
           <?php for($i = ($current_page-5 > 0 ? $current_page-5 : 1); $i < $current_page; $i++): ?>
           <a class="nav" href="<?php echo e(URL::current()); ?>?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
           <?php endfor; ?>
           <a class="nav nav-current"
               href="<?php echo e(URL::current()); ?>?page=<?php echo e($current_page); ?>" onclick="event.preventDefault();"><?php echo e($current_page); ?></a>
           <?php for($i = $current_page + 1; $i <= ($current_page + 5 > $last_page ? $last_page : $current_page + 5); $i++): ?>
            <a class="nav" href="<?php echo e(URL::current()); ?>?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
           <?php endfor; ?>

           <a class="nav <?php echo e($next_page_url ? '' : 'nav-disable'); ?>" href="<?php echo e($next_page_url); ?>" onclick="<?php echo e($next_page_url ? '' : 'event.preventDefault();'); ?>">&gt;</a>
        </div>
    <?php endif; ?> 
    
</div>
<div class="dialog" id="dialog">
   <div class="dialogContent">
       <div style="padding-top:20px;font-size:1.5em;">
          <span id="dialgTitle" class="two-lines"></span>
       </div>
       <div style="padding-top:10px;font-size:1.2em;">删除后不可恢复，请谨慎操作</div>
       <div style="position:absolute;bottom:40px;right:40px">
           <button id="cancel">取消</button>
           <button id="ok">确定</button>
       </div>
   </div>
</div>
<div id="msg-container" class="tip-msg">
  <span style="line-height:80px" id="msg-tip"></span>
</div>
<script src="<?php echo e(asset('js/jquery-1.8.3.min.js')); ?>"></script>
 
<script type="text/javascript">
	var isCheckAll = false;
    var ids = new Array();
	function swapCheck() {
		if (isCheckAll) {
			$("input[name='p']").each(function() {
				this.checked = false;
			});
			isCheckAll = false;
			ids.length = 0;
			$("#ids").val('');
		} else {
			ids.length = 0;
			$("input[name='p']").each(function() {
				this.checked = true;
				ids.push(this.value);
			});
			$("#ids").val(ids.join(','));
			isCheckAll = true;
		}
		changeDeleteSrc();
		
	}

	function changeDeleteSrc(){
		if(ids.length > 0){
			document.getElementById("delete-more-icon").src = "<?php echo e(asset('image/delete_n.png')); ?>";
		}else{
			document.getElementById("delete-more-icon").src = "<?php echo e(asset('image/delete_d.png')); ?>";
		}
	}

	function checkChange(obj){
		if(obj.checked){
			var c = true;
			$("input[name='p']").each(function() {
				if(!this.checked){
					c = false;
				}
			});
			if(c){
				isCheckAll = true;
	        	$('#check-all').attr("checked", true);
			}
        }else{
        	isCheckAll = false;
        	$('#check-all').attr("checked", false);
        }

		ids.length = 0;
		$("input[name='p']").each(function() {
			if(this.checked){
				ids.push(this.value);
			}
		});
		changeDeleteSrc();
		$("#ids").val(ids.join(','));
	}

	function changeMode(showId,hideId){
		var show = document.getElementById(showId);
		show.style.display="";

		var hide = document.getElementById(hideId);
		hide.style.display="none";
	}

	var optMore = false;
    var formId = null;
	function showDialog(more,id,title){
		formId = id;
		optMore= more;
		if(more){
			if(ids.length == 0){
				showMsg("请至少选择一个要删除的项目");
				return;
			}else{
				title = '';
				for(j = 0; j < ids.length; j++) {
					var e = document.getElementById("normal-"+ids[j]);
					title +=e.innerHTML;
					if(j != ids.length-1){
						title+="，";
					}
				} 
			}
        }
		var e = document.getElementById("dialog");
		e.style.display="block";
		
		if(title != null){
			var nv = document.getElementById("dialgTitle");
			nv.innerHTML="删除项目："+title;
		} 
	}

	function hideDialog(){
		var e = document.getElementById("dialog");
		e.style.display="none";
	}

	function showMsg(content){
		var e = document.getElementById("msg-container");
		e.style.display="block";
		var tip = document.getElementById("msg-tip");
		tip.innerHTML=content;
		setTimeout(hideMsg,2000);
	}

	function hideMsg(){
		var e = document.getElementById("msg-container");
		e.style.display="none";
	}
	
	 $(function(){
		$("#cancel").bind("click",function(){
	        hideDialog();
	    });

		$("#ok").bind("click",function(){
			var f = document.getElementById(formId);
			hideDialog();
			f.submit();
	    });
		 var x = 30;
		 var y = 30;
	    $("a.qr_code").mouseover(function(e) {
		    var src ="<?php echo e(route('web.qrcode')); ?>"+"?link="+this.href; 
	        var tooltip = "<div id='qr_code' style='position:absolute'><img src='" + src + "' width='160px' height='160px' /></div>";
	        //将层追加到文档中
	        //console.log(e);
	        console.log(this);
	        $("body").append(tooltip);
	        //设置层样式
	        $("#qr_code").css({
	            "top": (e.pageY - 80) + "px",
	            "left": (e.pageX + 24) + "px"
	        });
	    }).mouseout(function() {
	        $("#qr_code").remove();
	    });
    })
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    function fileSelect(itemId, elementId,path){
    	  var file = document.getElementById(elementId);
          if(file.value != ""){
               var formData = new FormData(document.getElementById("file-upload-"+itemId));
               $.ajax({
                 headers: {
                     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                     
                 },
                 type: 'POST',
                 url: path,
                 data: formData,
                 processData:false,
                 contentType: false,
                 //xhr:
                 success:function(data){
                     if(data != null && data.success){
                         showMsg(data.msg);
                         setTimeout(function () { window.location.reload(); }, 2000);
                     }
                 },
                 error:function(err){
                     console.log(err);
                 }
             }); 
         }
    }
    
</script>
<?php if(session('message') != null): ?>
<script type="text/javascript">
   showMsg('<?php echo e(session('message')); ?>');
</script>     
<?php endif; ?>
</body>
</html>
<?php /**PATH /Users/luligang/Documents/svn/code/AppDistribution/resources/views/uploads.blade.php ENDPATH**/ ?>