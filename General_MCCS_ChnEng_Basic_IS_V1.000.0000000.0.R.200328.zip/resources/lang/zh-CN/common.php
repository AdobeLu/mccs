<?php
return [
    
/*=========================add by luligang==========================*/
    'Close' => '关闭',
    'Save' => '保存',
    'Add' => '添加',
    'Delete' => '删除',
    'Edit' => '编辑',
    'Login' => '登录',
    'Logout' => '登出',
    'ResetPwd' => '密码重置',
    'verCode' => '验证码',
];