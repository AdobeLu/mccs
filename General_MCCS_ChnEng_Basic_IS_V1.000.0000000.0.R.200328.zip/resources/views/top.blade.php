<div class="top">
    	<div class="logo">
    	    @auth
    		   @if(Auth::user()['accountType'] == 'normal')
    		      <a href="{{route('index')}}"><img src="{{asset('image/logo.png')}}"></a>
    		   @else
    		     <img src="{{asset('image/logo.png')}}">
    		   @endif
    		@else 
    		  <a href="{{route('index')}}"><img src="{{asset('image/logo.png')}}"></a>
    		@endauth
    	</div>
    	<div class="user">
               @auth
                    <img src="{{asset('image/user_logo.png')}}" style="display:inline-block;vertival-align:middle;"> 
                   
                    <ul class="drop-nav">
                        <li class="drop-down">
            	            <a href="" class="userTv" >{{Auth::user()['name']}}</a>
                	        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                @csrf
                            </form>
                            <ul class="drop-down-content">
                                <!-- <li><a href="{{route('web')}}">静态部署</a></li> -->
                                <li><a href="{{route('logout')}}" onclick="event.preventDefault();logout('logout-form')">{{ __('common.Logout') }}</a></li>
                            </ul>
                        </li>
                        
                    </ul>
                @else
                    <a href="{{route('customLogin')}}" class="login">{{ __('common.Login') }}</a>
                @endauth
        </div>
</div>