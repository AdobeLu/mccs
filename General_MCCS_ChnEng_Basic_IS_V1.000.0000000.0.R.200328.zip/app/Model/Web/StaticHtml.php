<?php
namespace App\Model\Web;

use App\Model\Base\BaseModel;
use Illuminate\Support\Facades\Storage;

class StaticHtml extends BaseModel
{
    protected $table = 'static_htmls';
    protected $fillable = ['name', 'origin_name', 'real_path', 'status', 'user_id','link','zip_path','upload_times'];
    
    public static function deleteResource(){
        $ret = StaticHtml::query()->where("status", "=",1)->get()->toArray();
        if($ret){
            foreach($ret as $item){
                if($item['zip_path']){
                    if(Storage::disk('uploads')->exists($item['zip_path'])){
                        Storage::disk('uploads')->delete($item['zip_path']);
                    }
                    if($item['real_path']){
                        Storage::disk('uploads')->deleteDirectory($item['real_path']);
                    }
                }
                
                StaticHtml::find($item['id'])->delete();
            }
        }
    }
    
    /**
     * 
     * @param array $userIds
     * @return 
     */
    public static function deleteByIds($userIds){
        if(!$userIds){
            return 0;
        }
        if(is_array($userIds)){
            return StaticHtml::whereIn('user_id', $userIds)->update(['status' => 1]);
        }
        
        return StaticHtml::where('user_id', $userIds)->update(['status' => 1]);
    }
    
    /**
     *
     * @param $userId
     * @return
     */
    public static function deleteById($userId){
        if(!$userId){
            return 0;
        }
        $res = StaticHtml::where('user_id', $userId)->update(['status' => 1]);
        return $res;
    }
}

