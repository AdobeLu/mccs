<?php

namespace App\Http\Controllers;

use App\User;
use App\Model\Web\StaticHtml;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        if ($this->hasPermisision()) {
            $user = User::where('accountType','!=','admin')->paginate(20);
            return view('home', compact('user'));
        }else {
            return redirect('/');
        }
    }
    
    public function destroy(Request $request)
    {
        for($x=0;$x<count($request->get('keys'));$x++)
        {
            echo json_encode($request->get('keys'));
            $contact = User::find($request->get('keys')[$x]);
            StaticHtml::deleteById($request->get('keys')[$x]);
            if (!$contact->delete()) {
                return redirect('home')->with('failed', '用户删除失败，请确认!');
            }
        }
        return redirect('home')->with('success', 'User deleted!');
    }
    
    public function mutiDestroy(Request $request) {
        //添加事务，出错回滚
        DB::transaction(function() use($request){
            StaticHtml::deleteByIds($request->get('sub'));
            User::destroy($request->get('sub'));
        });
        return redirect('home')->with('success', __("user.userDeleteSuccess"));
    }
    
    private function hasPermisision() {
        return Auth::user()->accountType == 'admin';
    }
}
