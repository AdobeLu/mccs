<?php

namespace App\Exceptions;


use Illuminate\Auth\AuthenticationException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Exception;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Symfony\Component\HttpKernel\Exception\HttpException;

class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that are not reported.
     *
     * @var array
     */
    protected $dontReport = [
        //\Illuminate\Auth\AuthenticationException::class,
        //\Illuminate\Auth\Access\AuthorizationException::class,
        //\Symfony\Component\HttpKernel\Exception\HttpException::class,
        //\Illuminate\Database\Eloquent\ModelNotFoundException::class,
        //\Illuminate\Session\TokenMismatchException::class,
        //\Illuminate\Validation\ValidationException::class,

    ];

    /**
     * A list of the inputs that are never flashed for validation exceptions.
     *
     * @var array
     */
    protected $dontFlash = [
        'password',
        'password_confirmation',
    ];

    /**
     * Report or log an exception.
     *
     * @param  \Exception  $exception
     * @return void
     *
     * @throws \Exception
     */
    public function report(Exception $e)
    {
        parent::report($e);
        
    }

    /**
     * Render an exception into an HTTP response.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Exception  $exception
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @throws \Exception
     */
    public function render($request, Exception $e)
    {
        if($e instanceof \Symfony\Component\ErrorHandler\Error\FatalError 
            && !config('app.debug')) {
                if ($request->ajax() || $request->wantsJson()) {
                    return  response()->json([
                        'msg' => __('err.msg.m_50000'),
                        'code' => __('err.code.c_50000'),
                        'success'=>false
                    ]);
                }else{
                    return response()->view("errors.500");
                }
        }
        
        $httpCode = [400,403,404,500,501,502,503,504];
        if($e instanceof HttpException){
           $code = $e->getStatusCode();
           if(in_array($code, $httpCode)){
               if ($request->ajax() || $request->wantsJson()) {
                   return  response()->json([
                       'msg' => __('err.'.$code.'.msg'),
                       'code' => __('err.'.$code.'.code'),
                       'success'=>false
                   ]);
               }else if(view()->exists("errors.".$code)){
                   return response()->view("errors.".$code);
               }else {
                   return response()->view("errors.default");
               }
           }
           
        }
        if( $e instanceof AuthenticationException){
            
            if ($request->ajax() || $request->wantsJson()) {
                return  response()->json([
                    'msg' => __('err.401.msg'),
                    'code' => __('err.401.code'),
                    'success'=>false
                ]);
            }
            return parent::render($request, $e);
        }
        if ($e instanceof NotFoundHttpException) {
            if ($request->ajax() || $request->wantsJson()) {
                return  response()->json([
                    'msg' => __('err.msg.m_40004'),
                    'code' => __('err.code.c_40004'),
                    'success'=>false
                ]);
            } else {
                return response()->view('errors.404');
            }
        }
        return parent::render($request, $e);
    }
}
