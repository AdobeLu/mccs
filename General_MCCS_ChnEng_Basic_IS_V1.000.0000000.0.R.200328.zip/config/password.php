<?php
return [
    
    /**
     * 最小长度
     */
    'minimum_length' => env('PASSWORD_LENGTH', 8),
    
    /**
     * 密码要求
     */
    'requirements'   => [
        '[0-9]',
        '[a-z]',
        '[A-Z]',
        '[!@#$%^&*()]',
    ],
];