<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Util\CommonHelper;

class EncryptTest extends TestCase
{
    /**
     * A basic feature test example.
     *
     * @return void
     */
    public function testExample()
    {
        $str = 'root';
        echo storage_path("backup");
        $token = CommonHelper::encryptCommon($str);
        echo '加密:'.$token;
        echo '解密：'.CommonHelper::decryptCommon($token);
        echo '     ';
        $str = 'root';
        $token = CommonHelper::encryptCommon($str);
        echo '加密:'.$token;
        echo '解密：'.CommonHelper::decryptCommon($token);
       
    }
}
