<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Illuminate\Cache\RetrievesMultipleKeys;
use Illuminate\Support\MessageBag;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Contracts\Support\MessageProvider;
use App\Util\RSA;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    protected $decayMinutes = 5;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('dataIntegrity');
        $this->middleware('guest')->except('logout');
    }
    
    public function username()
    {
        return 'name';
    }
    
    public function myLoginForm(Request $request) {
        $times = $this->limiter()->attempts($request->ip());
        $token = md5(time());
        $request->session()->put($token, 1);
        $request->session()->save();
        return view('auth.login',['attempts' => $times, 'nonce' => $token]);
    }
    
    public function getPK(Request $request) {
        $rsa = new RSA();
        $keys = $rsa->new_rsa_key();
        Cache::put($keys['pubkey'], $keys['privkey'], 5);
        return ['result' => 200, 'pk' => $keys['pubkey']];
    }
    
    public function customLogin(Request $request)
    {
        $token = $request->input('nonce');
        if (empty($token)) {
            abort(403, 'data error');
        }
        if(empty($request->session()->get($token))) {
            abort(403, 'data expired');
        }
        $request->session()->forget($token);
        $validataParam = [
            'name' => 'required|string',
            'password' => 'required|string',];
        if ($this->limiter()->attempts($request->ip()) > 0) {
            $validataParam = [
                'verCode' => 'required|captcha',
                'name' => 'required|string',
                'password' => 'required|string',];
        }
        $request->validate($validataParam);
        $rsa = new RSA();
        if (Cache::has($request->get('pk'))) {
            $key = "-----BEGIN PRIVATE KEY-----\n" . wordwrap(Cache::pull($request->get('pk')), 64, "\n", true) . "\n-----END PRIVATE KEY-----";
            $rsa->init($key, $request->get('pk'),true);
        }
        $request['password'] = $rsa->priv_decode($request->get('password'));
        // If the class is using the ThrottlesLogins trait, we can automatically throttle
        // the login attempts for this application. We'll key this by the username and
        // the IP address of the client making these requests into this application.
        if (method_exists($this, 'hasTooManyLoginAttempts') &&
            $this->hasTooManyLoginAttempts($request)) {
                $this->fireLockoutEvent($request);
                
                return $this->sendLockoutResponse($request);
            }
            
            if ($this->attemptLogin($request)) {
                Auth::logoutOtherDevices($request['password']);//登出其他终端
                return $this->sendcustomLoginResponse($request);
            }
            
            // If the login attempt was unsuccessful we will increment the number of attempts
            // to login and redirect the user back to the login form. Of course, when this
            // user surpasses their maximum number of attempts they will get locked out.
            $this->incrementLoginAttempts($request);
            return $this->sendFailedLoginResponse($request, $this->limiter()->attempts($request->ip()));
            
    }
    
    protected function sendFailedLoginResponse(Request $request,$times)
    {
        throw ValidationException::withMessages([
            $this->username() => __('auth.failed'),
            "attempts" => $times
        ]);
    }
    
    protected function throttleKey(Request $request)
    {
        return $request->ip();//根据ip锁定账户
    }
    
    protected function sendcustomLoginResponse(Request $request)
    {
        $request->session()->regenerate();
        
        $this->clearLoginAttempts($request);
        
        return $this->customAuthenticated($request, $this->guard()->user())
        ?: redirect()->intended($this->redirectPath());
    }
    
    protected function customAuthenticated(Request $request, $user)
    {
        //
        if ($user->accountType == "admin") {
            return redirect('home');
        }else {
            return redirect('/');
        }
    }
    
    /**
     * 私钥解密
     *
     * @param string 密文（二进制格式且base64编码）
     * @param string 密文是否来源于JS的RSA加密
     * @return string 明文
     */
    private function decodeing($crypttext,$key)
    {
        $key_content = $key;
        $prikeyid    = openssl_get_privatekey($key_content);
        $crypttext   = base64_decode($crypttext);
        
        if (openssl_private_decrypt($crypttext, $sourcestr, $prikeyid, OPENSSL_PKCS1_PADDING))
        {
            return "".$sourcestr;
        }
        return ;
    }
    
    public function logout(Request $request)
    {
        $uId = Auth::id();
        $ip = $request->ip();
        $this->guard()->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();
        Log::channel('key')->info(sprintf("%s#%s#%s#", $uId, $ip,"退出登录"));
        if($request->ajax()){
            return response()->json([
                'msg' => "登出成功",
                'data' => ['url' => url("")],
                'code' =>  __('err.code.c_10000'),
                'success'=>TRUE
            ]);
        }
        return redirect('/');
    }
}
