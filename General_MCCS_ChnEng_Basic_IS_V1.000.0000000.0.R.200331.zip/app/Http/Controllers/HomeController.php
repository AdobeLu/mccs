<?php

namespace App\Http\Controllers;

use App\User;
use App\Model\Web\StaticHtml;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        if ($this->hasPermisision()) {
            $user = User::where('accountType','!=','admin')->latest('id')->paginate(5);
            if(count($user->items()) == 0) {
                if ($user->lastPage() < $user->currentPage()) {
                    $user = User::where('accountType','!=','admin')->latest('id')->paginate(5,['*'],'page',$user->lastPage());
                }
            }
            return view('home', compact('user'));
        }else {
            return redirect('/');
        }
    }
    
    public function destroy(Request $request)
    {
        for($x=0;$x<count($request->get('keys'));$x++)
        {
            echo json_encode($request->get('keys'));
            $user = User::find($request->get('keys')[$x]);
            $contact = User::find($user->id);
            StaticHtml::deleteById($user->id);
            if (!$contact->delete()) {
                Log::channel('key')->info('用户'.Auth::user()->name.'删除'.$user->id.'失败');
                return redirect('home')->with('failed', '用户删除失败，请确认!');
            }
            Log::channel('key')->info('用户'.Auth::user()->name.'删除了用户:'.$user->id);
        }
        return back()->with('success', __('user.userDeleteSuccess'));
    }
    
    public function mutiDestroy(Request $request) {
        //添加事务，出错回滚
        DB::transaction(function() use($request){
            StaticHtml::deleteByIds($request->get('sub'));
            User::destroy($request->get('sub'));
            Log::channel('key')->info('用户'.Auth::user()->name.'删除了一组用户:'.json_encode($request->get('sub')));
        });
        return back()->with('success', __('user.userDeleteSuccess'));
    }
    
    private function hasPermisision() {
        return Auth::user()->accountType == 'admin';
    }
}
