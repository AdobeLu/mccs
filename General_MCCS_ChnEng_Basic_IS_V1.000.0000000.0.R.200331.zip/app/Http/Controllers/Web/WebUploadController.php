<?php
namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Model\Web\StaticHtml;
use App\Util\GenerateCode;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use ZipArchive;
#use SimpleSoftwareIO\QrCode\Facades\QrCode;
use Illuminate\Support\Facades\Auth;

class WebUploadController extends Controller
{
    
    public function __construct()
    {
        $this->middleware('dataIntegrity');
    }
    /**
     * 通过ajax文件上传
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    
    public function upload(Request $request){
         $validator = Validator::make($request->input(), [
            'id' => 'required|integer',
         ]);
         if($validator->failed()){
             return response()->json([
                 'msg' => __('err.msg.m_10005'),
                 'code' =>  __('err.code.c_10005'),
                 'success'=>FALSE
             ]);
         }
         $exts = array("zip");
         $id = $request->input("id");
         $sh = StaticHtml::find($id);
         $msg =__('webs.web_upload_fail');
         $code = 10001;
         $success = FALSE;
         $uNmae = Auth::user()['name'];
         $ip = $request->ip();
         $ofileName = "";
         if($sh != null){
             if ($request->isMethod('POST')){
                 $file = $request->file('file');
                 //判断文件是否上传成功
                 if ($file->isValid()){
                     $ofileName = $originalName = $file->getClientOriginalName();
                     $ext = $file->getClientOriginalExtension();
                     $size = $file->getSize();
                     if($size > config("mccs.file_max_size") * 1024 * 1024){
                         $msg = __('webs.web_file_size',['size' => config("mccs.file_max_size")]);
                     }else{
                         if(in_array($ext, $exts)){
                             $real_path = $sh['real_path'];
                             $times = $sh['upload_times']+1;;
                             $base = $sh['link']."_".$times;
                             $old_zip = $sh['zip_path'];
                             $realPath = $file->getRealPath();
                             $filename = $base.'.'.$ext;
                             
                             $bool = Storage::disk('uploads')->put($filename,file_get_contents($realPath));
                             if($bool){
                                 $zip = new ZipArchive();
                                 $path = Storage::disk('uploads')->path($filename);
                                 if ($zip->open($path) === true) {
                                     if($zip->numFiles > 0){
                                         $html = false;
                                         for($i = 0; $i < $zip->numFiles; $i++) {
                                             $name = $zip->getNameIndex($i);
                                             /*if($name && strpos($name,config('mccs.web_index'))){
                                              $html = TRUE;
                                              break;
                                              } */
                                             if($name){
                                                 $arr = explode("/",$name);
                                                 if(count($arr) == 2 && $arr[1] != null && $arr[1] == config('mccs.web_index')){
                                                     $html = TRUE;
                                                 }
                                             }
                                         }
                                         if(!$html){
                                             Storage::disk('uploads')->delete($filename);
                                             Log::channel('security')->info(sprintf("%s#%s#上传压缩包没有%s#%s", $uNmae, $ip,config('mccs.web_index'),$filename));
                                             return  response()->json([
                                                 'msg' => __('webs.web_index_html'),
                                                 'code' => $code,
                                                 'success'=>$success
                                                 
                                             ]);
                                         }
                                         $dir = $zip->getNameIndex(0);
                                         $res = $zip->extractTo(Storage::disk('uploads')->path($base."_tmp"));
                                         if($res){
                                             $fs = Storage::disk('uploads')->allFiles($base."_tmp");
                                             for ($i =0; $i < count($fs);$i++){
                                                 $p = $fs[$i];
                                                 $n=$base."/".substr($p ,strlen($base."_tmp/".$dir));
                                                 Storage::disk('uploads')->move($p, $n);
                                             }
                                             Storage::disk('uploads')->deleteDirectory($base."_tmp");
                                         }
                                     }
                                     $zip->close();
                                     $arr = Storage::disk('uploads')->allFiles($base);
                                     foreach ($arr as $v){
                                         $path =  public_path("html/".$v);
                                         chmod($path, 0666);
                                     }
                                     $data = array();
                                     $data['origin_name'] = $originalName;
                                     $data['real_path'] = $base;
                                     $data['zip_path'] = $filename;
                                     $data['upload_times'] = $times;
                                     $s = new StaticHtml();
                                     $res = $s->checkUpdate($id, $data);
                                     if($res){
                                         if($old_zip){
                                             if(Storage::disk('uploads')->exists($old_zip)){
                                                 Storage::disk('uploads')->delete($old_zip);
                                             }
                                             Storage::disk('uploads')->deleteDirectory($real_path);
                                         }
                                         $msg = __('webs.web_upload_success');
                                         $code = __('err.code.c_10000');
                                         $success = TRUE;
                                     }else {
                                         if(Storage::disk('uploads')->exists($filename)){
                                             Storage::disk('uploads')->delete($filename);
                                         }
                                         Storage::disk('uploads')->deleteDirectory($base);
                                     }
                                 }else {
                                     if(Storage::disk('uploads')->exists($filename)){
                                         Storage::disk('uploads')->delete($filename);
                                     }
                                     Storage::disk('uploads')->deleteDirectory($base);
                                 }
                             }
                         }else{
                             $msg = __('webs.web_mimetype_fail');
                         }
                     }
                 }else{
                     $msg = __('webs.web_file_invalidate');
                 }
             }
         }
         if(!$success){
             Log::channel('security')->info(sprintf("%s#%s#%s#%s", $uNmae, $ip,$msg,$ofileName));
         }
         return response()->json([
             'msg' => $msg,
             'code' => $code,
             'success'=>$success
           
         ]);
    }
    
    
    public function index(Request $request){
         $size = 20;
         $page = $request->input('page',1);
         if($page <= 0){
             $page = 1;
         }
         $pageSize = $request->input('pageSize',20);
         if($pageSize < 0){
             $pageSize = 20;
         }
         $size = $pageSize;
         $user = Auth::user();
         $type = $user['accountType'] == 'admin';
         if($type){
             return redirect()->route('home');
         }
         $htmls = StaticHtml::query()
            ->select('id', 'name','origin_name','real_path','link','zip_path')
            ->where('status', '=',0);
        if(!$type){
            $htmls =$htmls ->where('user_id','=',Auth::id());
        }
        
        $htmls =$htmls->orderByDesc('id')
        ->paginate($size)->toArray();
        if($htmls['last_page']  < $page){
            return response()->redirectToRoute("web",['page' => $htmls['last_page'],'pageSize' => $size]);
        }
        $c_id = $request->session()->get('c_id');
        if($c_id != null){
            $htmls['c_id'] = $c_id;
        }
        return view('web',$htmls);
         
    }
    
    public function delete(Request $request)
    {
        $input = $request->input();
       
        $validator = Validator::make($request->input(), [
            'id' => 'required|integer',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'msg' => __('webs.web_delete_fail'),
                'code' =>  __('err.code.c_10005'),
                'success'=>FALSE
            ]);
        }
        $sh = StaticHtml::find($input['id']);
        if(!$sh){
           return response()->json([
               'msg' => __('webs.web_delete_fail'),
               'code' =>  __('err.code.c_40004'),
               'success'=>FALSE
           ]);
        }
        $res = false;
        if($sh['zip_path']){
            //$res = StaticHtml::where('id', '=', $input['id'])->update(['status' => 1]);
            $res = $sh->update(['status' => 1]);
        }else {
            //$res = StaticHtml::find($input['id'])->delete();
            $res = $sh->delete();
        }
        $uNmae = Auth::user()['name'];
        $ip = $request->ip();
        if($res){
            Log::channel('key')->info(sprintf("%s#%s#%s#%s", $uNmae, $ip,__('webs.web_delete_success'),$input['id']));
            //return back()->with("message",__('webs.web_delete_success'));
            return response()->json([
                'msg' => __('webs.web_delete_success'),
                'code' =>  __('err.code.c_10000'),
                'success'=>TRUE
            ]);
        }else {
            Log::channel('key')->info(sprintf("%s#%s#%s#%s", $uNmae, $ip,__('webs.web_delete_fail'),$input['id']));
            //return back()->with("message",__('webs.web_delete_fail'));
            return response()->json([
                'msg' => __('webs.web_delete_fail'),
                'code' => 10001,
                'success'=>FALSE
            ]);
        }
    }
    
    public function link($link,Request $request){
        if($link && preg_match("/^[a-zA-Z0-9]{6}$/", $link)){
            $data = StaticHtml::where('link', '=', $link)->first();
            if($data){
                $sh = $data->toArray();
                $realLink = $sh['real_path'] ? $sh['real_path']."/".config('mccs.web_index') : null;
                if($realLink && Storage::disk('uploads')->exists($realLink)){
                    return redirect(asset("html/".$realLink));
                    //return Storage::disk('uploads')->get($realLink);
                }
            }
        }
        abort(404);
    }
    
    public function create(Request $request){
        $code = GenerateCode::randCode();
        while (true) {
           $sh = StaticHtml::query()
           ->where('link', "=",$code)->first();
           if($sh == null){
               break;
           }else{
               $code = GenerateCode::randCode();
           }
        }
        $web = array();
        $web['name'] = __('webs.web_project',['code' => $code]);
        $web['link'] = $code;
        $web['user_id'] = Auth::id();
        $sh = new StaticHtml();
        $res = $sh->fill($web)->save();
        if($res){
            $id = $sh->toArray()['id'];
            if($request->ajax()){
                $request->session()->flash('c_id', $id);
                return response()->json([
                    'msg' => __('webs.web_add_success'),
                    'data' =>['id' => $id,
                        'url' => route("web",['page' => 1])
                    ],
                    'code' => __('err.code.c_10000'),
                    'success'=>TRUE
                ]);
            }
            return redirect()->route('web')->with("c_id",$id)->with("message",__('webs.web_add_success'));
            
        }else{
            if($request->ajax()){
                return response()->json([
                    'msg' =>__('webs.web_add_fail'),
                    'code' => 10001,
                    'success'=>FALSE
                ]);
            }
            return back()->with("message",__('webs.web_add_fail'));
        }
    }
    
    /**
     * 通过ajax
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function changeName(Request $request){
        $input = $request->input();
        $name = $input['name'];
        if(!preg_match("/^[a-zA-Z0-9\x{4e00}-\x{9fa5}]{1,64}$/u", $name)){
            return response()->json([
                'msg' => __('webs.web_name_limit'),
                'code' => '10001',
                'success'=>FALSE
                
            ]);
        }
        $validator = Validator::make($request->all(), [
            'id' => 'required',
            'name' => 'required|unique:static_htmls|max:200',
        ]);
        
        if ($validator->fails()) {
            return response()->json([
                'msg' => __('webs.web_name_exist', ['name' => $name]),
                'code' => '10001',
                'success'=>FALSE
                
            ]);
        }
        
        $sh = new StaticHtml();
        $res = $sh->checkUpdate($input['id'], $input);
        
        if ($res) {
            return response()->json([
                'msg' => __('webs.web_modify_success'),
                'code' => __('err.code.c_10000'),
                'success'=>TRUE,
                'data' => [
                    'id' =>$input['id'],
                    'name' => $input['name']
                ]
                
            ]); 
        }
        return response()->json([
            'msg' =>  __('webs.web_modify_fail'),
            'code' => '10001',
            'success'=>FALSE,
        ]);
    }
    
    public function deleteMore(Request $request)
    {
        $input = $request->input();
       
        $validator = Validator::make($request->input(), [
            'ids' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'msg' => __('webs.web_delete_fail'),
                'code' => __('err.code.c_10005'),
                'success'=>FALSE
            ]);
        }
        if(strlen($input['ids']) == 0 ){
            //return back()->with("message",__('webs.web_delete_fail'));
            return response()->json([
                'msg' => __('webs.web_delete_fail'),
                'code' => 10002,
                'success'=>FALSE
            ]);
        }
        $uName = Auth::user()['name'];
        $ip = $request->ip();
        $res = StaticHtml::whereIn('id', explode(",", $input['ids']))->update(['status' => 1]);
        if($res){
            Log::channel('key')->info(sprintf("%s#%s#%s#%s", $uName, $ip,__('webs.web_delete_success'),$input['ids']));
            //return back()->with("message",__('webs.web_delete_success'));
            return response()->json([
                'msg' => __('webs.web_delete_success'),
                'code' =>__('err.code.c_10000'),
                'success'=>TRUE
            ]);
        }else {
            Log::channel('key')->info(sprintf("%s#%s#%s#%s", $uName, $ip,__('webs.web_delete_fail'),$input['ids']));
            //return back()->with("message",__('webs.web_delete_fail'));
            return response()->json([
                'msg' => __('webs.web_delete_fail'),
                'code' => 10001,
                'success'=>FALSE
            ]);
        }
    }
    
    public function downloadZip($id){
        if(!$id){
            abort(404);
        }
        $sh = StaticHtml::find($id);
        
        if($sh){
            $zipPath = $sh['zip_path'];
            $origin_name=$sh['origin_name'];
            if($zipPath && Storage::disk('uploads')->exists($zipPath)){
                return Storage::disk('uploads')->download($zipPath,$origin_name);
            }
        }
        
        abort(404);
    }
    
    /* public function qrCode(Request $request)
    {
        $link = $request->input('link');
        if(!$link){
            abort(404);
        }
        
        $data=  QrCode::format('png')->margin(0)->size(160)->generate($link);
       // dd($data);
       // $url = "data:image/png;base64,".base64_encode($data);
        
        return response($data)->header('Content-Type', 'image/png');
    } */
    
    /* public function download($id){
        $sh = StaticHtml::find($id);
        if($sh){
            $zipPath = $sh['zip_path'];
            $origin_name=$sh['origin_name'];
            dd(Storage::disk('uploads')->exists($zipPath));
            if($zipPath && Storage::disk('uploads')->exists($zipPath)){
                return Storage::disk('uploads')->download($zipPath,$origin_name);
            }
        }
        
        return back();
    } */
}

