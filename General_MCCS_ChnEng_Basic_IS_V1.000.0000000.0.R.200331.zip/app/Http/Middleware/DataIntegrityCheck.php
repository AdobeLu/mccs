<?php

namespace App\Http\Middleware;

use App\Util\SignVerify;
use Illuminate\Support\Facades\Log;
use Closure;

class DataIntegrityCheck
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        try {
            if($request->isMethod('GET')){
                return $next($request);
            }
            $input = $request->input();
            //Log::info($input);
            $url = null;
            if(isset($input['_url'])){
                $url = $input['_url'];
                unset($input['_url']);
            }
            
            $ret = SignVerify::verifySign($input['_token'],$input);
            //Log::info($ret);
            if($url != null){
                $input['_url'] = $url;
            }
            if($ret == 1){
                return $next($request);
            }else {
                $code = 100001;
                $msg = '';
                switch ($ret){
                    case 0:
                        $code =__('err.code.c_10005');
                        $msg = __('err.msg.m_10005');
                        break;
                    case 2:
                        $code = __('err.code.c_10003');
                        $msg = __('err.msg.m_10003');
                        break;
                    case 3:
                        $code = __('err.code.c_10002');
                        $msg = __('err.msg.m_10002');
                        break;
                    case 4:
                        $code = __('err.code.c_10004');
                        $msg = __('err.msg.m_10004');
                        break;
                        
                }
            }
            
            if($request->ajax()){
                return response()->json([
                    'msg' => $msg,
                    'code' => $code,
                    'success'=>false
                ]);
            }else{
                return back()->with("message",$msg);
            } 
        }catch (\Exception $e){
            if($request->ajax()){
                return response()->json([
                    'msg' => "服务异常",
                    'code' => 50000,
                    'success'=>false
                ]);
            }else {
                return back();
            }
        }
    }
}
