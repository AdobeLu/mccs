var signData = function(form, timestamp){
	var obj = serializeForm(form);
	obj['timestamp'] = timestamp;
	delete obj.sign;
	return md5(jsonSort(obj)+obj._token);
}
var serializeForm=function(form){
        var parts= {},
            field=null,
            i,
            len,
            j,
            optLen,
            option,
            optValue;
        for(i = 0, len = form.elements.length;i<len;i++){
            field=form.elements[i];
            switch (field.type){
                case 'select-one':
                case 'select-multiple':
                    if(field.name.length){
                    	optValue='';
                        for(j=0,optLen=field.options.length;j<optLen;j++){
                            option=field.options[j];
                            if(option.selected){
                               
                                if(option.hasAttribute){
                                    optValue+=(option.hasAttribute('value')?option.value:option.text);
                                } else {
                                    optValue+=(option.attributes['value'].specified?option.value:option.text);
                                }
                            }
                        }
                        //parts.set(encodeURIComponent(field.name),encodeURIComponent(optValue));
                        parts[encodeURIComponent(field.name)] = encodeURIComponent(optValue);
                    }
                    break;
                case undefined: //字段集
                case 'file':
                case 'submit':
                case 'reset':
                case 'button':
                    break;
                case 'radio':
                case 'checkbox':
                    if(!field.checked){
                        break;
                    }
                default :
                    if(field.name.length){
                        //parts.set(encodeURIComponent(field.name),encodeURIComponent(field.value));
                        parts[encodeURIComponent(field.name)] = encodeURIComponent(field.value);
                    }
            }
        }
        return parts;
 }
var jsonSort = function (jsonObj) {
    let arr=[];
    for(var key in jsonObj){
        arr.push(key)
    }
    arr.sort();
    let str='';
    for(var i in arr){
       str +=arr[i]+"="+jsonObj[arr[i]]+"&"
    }
    return str;
}