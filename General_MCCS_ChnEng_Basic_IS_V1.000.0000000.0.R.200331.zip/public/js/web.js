var isCheckAll = false;
var ids = new Array();
function swapCheck() {
	if (isCheckAll) {
		$("input[name='p']").each(function() {
			this.checked = false;
		});
		isCheckAll = false;
		ids.length = 0;
		$("#ids").val('');
	} else {
		ids.length = 0;
		$("input[name='p']").each(function() {
			this.checked = true;
			ids.push(this.value);
		});
		$("#ids").val(ids.join(','));
		isCheckAll = true;
	}
	changeDeleteSrc();
	
}

function changeDeleteSrc(){
	if(ids.length > 0){
		document.getElementById("delete-more-icon").src = "image/delete_n.png";
		document.getElementById("delete-more-txt").style.color="#151c29"
	}else{
		document.getElementById("delete-more-icon").src = "image/delete_d.png";
		document.getElementById("delete-more-txt").style.color="#9e9e9e"
	}
}

function checkChange(obj){
	if(obj.checked){
		var c = true;
		$("input[name='p']").each(function() {
			console.log(this.checked);
			if(!this.checked){
				c = false;
			}
		});
		console.log("c="+c);
		if(c){
			isCheckAll = true;
			$("#check-all").prop("checked", true);
		}else{
			isCheckAll = false;
			$("#check-all").prop("checked", false);
		}
    }else{
    	isCheckAll = false;
    	$("#check-all").prop("checked", false);
    }

	ids.length = 0;
	$("input[name='p']").each(function() {
		if(this.checked){
			ids.push(this.value);
		}
	});
	changeDeleteSrc();
	$("#ids").val(ids.join(','));
}

function changeMode(showId,hideId,inputId){
	var show = document.getElementById(showId);
	show.style.display="";

	var hide = document.getElementById(hideId);
	hide.style.display="none";
	$("#"+inputId).val(show.innerText); 
}

var optMore = false;
var formId = null;
function showDialog(more,id,title){
	formId = id;
	optMore= more;
	if(more){
		if(ids.length == 0){
			return;
		}else{
			title = '';
			for(j = 0; j < ids.length; j++) {
				var e = document.getElementById("normal-"+ids[j]);
				title +=e.innerHTML;
				if(j != ids.length-1){
					title+="，";
				}
			} 
		}
    }
	var e = document.getElementById("dialog");
	e.style.display="block";
	
	if(title != null){
		var nv = document.getElementById("dialgTitle");
		nv.innerHTML=delete_items+title;
	} 
}

function hideDialog(){
	var e = document.getElementById("dialog");
	e.style.display="none";
}

function showMsg(content, success){
	var tip = document.getElementById("msg-tip");
	tip.innerText=content;
	var e = document.getElementById("msg-container");
	e.style.display="block";
	if(success){
		e.style.backgroundColor="#0CA646";
	}else{
		e.style.backgroundColor="#E85956";
	}
	setTimeout(hideMsg,2000);
}

function hideMsg(){
	var e = document.getElementById("msg-container");
	e.style.display="none";
}

function hideLoading(){
	var e = document.getElementById("loading");
	e.style.display="none";
}

function showLoading(){
	var e = document.getElementById("loading");
	e.style.display="block";
}

 $(function(){
	$("#cancel").unbind('click').click(function(){
		hideDialog();
	});
	$("#ok").unbind('click').click(function(){
		hideDialog();
		var form = document.getElementById(formId);
		deleteData(form);
	});
    var x = 24;
    var y = -150;
    $("a.qr_code").unbind('click').click(function(e) {
    	$("#qr_code").remove();
    	var txt = this.href;
    	var tooltip = "<div id='qr_code' style='position:absolute;text-align:center;box-shadow: 0 0px 10px 0 rgba(0,0,0,0.2), 0 2px 10px 0 rgba(0,0,0,0.19);background-color: #fff;padding:10px 10px; width:300px;height:300px;top:"+ (e.pageY + y) + "px;left:"+(e.pageX + x)+"px;'>" +
    	        "<span style='margin-top:10px;color:#151C29;display:block;height:24px;line-height:24px'>"+this.title+"</span>"+
    	        "<div id='qr_code_img' style='margin-top:16px;margin-bottom:16px;'></div>" +
    			"<a href='' download='' id='qr_code_a' style='color:#151C29;display:inline-block;height:24px;line-height:24px'>导出二维码</a></div>";
        $("body").append(tooltip);
        jQuery('#qr_code_img').qrcode({
            render: "canvas",
            width: 200,
            height: 200,
            text: txt
        });
        var data = $("canvas")[0].toDataURL().replace("image/png", "image/octet-stream;"); 　
    	var filename = this.title+"_"+txt.substring(txt.lastIndexOf("/")+1)+".png";
    	$("#qr_code_a").attr("href",data); 
    	$("#qr_code_a").attr("download",filename);
    	document.addEventListener('click',function (e1) {
    		var parent=$(e1.target).parents('.qr_code');
    		if(parent.length == 0){
    			$("#qr_code").remove();
    		}
       });
    });
});
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
 
function deleteData(form){
    showLoading();
    $.ajax({
      headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          
      },
      type: form.method,
      url: form.action,
      data: signFormData(form,false),
      processData:false,
      contentType: false,
      success:function(data){
     	  hideLoading();
          if(data != null && data.success){
              showMsg(data.msg,true);
              setTimeout(function () { window.location.reload(); }, 1000);
          }else if(data != null){
         	 showMsg(data.msg,false);
         	 expireSession(data);
          }
      },
      statusCode: {
    	  401: function() {
    		  showMsg("会话失效，请重新登录",false);
              setTimeout(function () {  window.location.reload(); }, 1000);
    	  }
      },
      error:function(err){
     	 hideLoading();
     	 showMsg("服务异常",false);
      }
  }); 
}
function createWeb(formId){
	var form = document.getElementById(formId);
    showLoading();
    $.ajax({
      headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          
      },
      type: form.method,
      url: form.action,
      data: signFormData(form,false),
      processData:false,
      contentType: false,
      success:function(data){
     	  hideLoading();
          if(data != null && data.success){
              showMsg(data.msg,true);
              setTimeout(function () {  
            	 // window.location.reload();
            	    window.location.href = data.data.url;
            	  }, 100);
          }else if(data != null){
         	 showMsg(data.msg,false);
         	 expireSession(data);
          }
      },
      statusCode: {
    	  401: function(data) {
    		  showMsg("会话失效，请重新登录",false);
              setTimeout(function () {  window.location.reload(); }, 1000);
    	  }
      },
      error:function(xhr,textStatus,err){
     	 hideLoading();
     	 showMsg("服务异常",false);
      }
  }); 
}

function expireSession(data){
	if(data && !data.success){
		if(data.code == '40001'){
			setTimeout(function () {  window.location.reload(); }, 1000);
		}
	}
}

function fileSelect(itemId, elementId,path){
	  var file = document.getElementById(elementId);
      if(file.value != ""){
    	  var fileName = file.value.substring(file.value.lastIndexOf(".")+1).toLowerCase();
          if(fileName !="zip"){
        	  file.value="";
              showMsg(zip_limit,false);
              return
          }
          console.log(file.files[0].size);
          if(file.files[0].size > file_max_size * 1024 * 1024){
        	  file.value="";
              showMsg(file_size_limit,false);
        	  return;
          }
           var form = document.getElementById("file-upload-"+itemId);
           showLoading();
           $.ajax({
             headers: {
                 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                 
             },
             type: 'POST',
             url: path,
             data: signFormData(form,false),
             processData:false,
             contentType: false,
             success:function(data){
            	 hideLoading();
            	 file.value="";
                 if(data != null && data.success){
                     showMsg(data.msg,true);
                     setTimeout(function () { window.location.reload(); }, 1000);
                 }else if(data != null){
                	 showMsg(data.msg,false);
                	 expireSession(data);
                 }
             },
             statusCode: {
           	  401: function() {
           		  showMsg("会话失效，请重新登录",false);
                  setTimeout(function () {  window.location.reload(); }, 1000);
           	  }
             },
             error:function(err){
            	 hideLoading();
            	 file.value="";
            	 showMsg("服务异常",false);
             }
         }); 
     }
}
function logout(formId){
	var form = document.getElementById(formId);
    $.ajax({
      headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          
      },
      type: form.method,
      url: form.action,
      data: signFormData(form,false),
      processData:false,
      contentType: false,
      success:function(data){
          if(data != null && data.success){
        	  if(data.data != null && data.data.url != null && data.data.url.startsWith('http')){
        		  window.location.href= encodeURI(data.data.url);
        	  }else{
        		  window.location.reload();
        	  }
          }else if(data != null){
        	  expireSession(data);
          }
      },
      statusCode: {
    	  401: function() {
    		  showMsg("会话失效，请重新登录",false);
              setTimeout(function () {  window.location.reload(); }, 1000);
    	  }
      },
      error:function(err){
    	 
      }
  }); 
}

function changeNameUp(itemId, elementId,path){
	event.preventDefault();
	if(event.keyCode == "13"){
		var form = document.getElementById("form-name-"+itemId);
		if(form.style.display == "none"){
			return;
		}
		changeName(itemId, elementId,path);
	}
}
function changeNameDown(itemId){
	if(event.keyCode == "13"){
		event.preventDefault();
	}
}
function changeName(itemId, elementId,path){
	var form = document.getElementById("form-name-"+itemId);
	var qrName = document.getElementById("qr-"+itemId);
	var name = form['name'].value;
	if(name== null || name.length < 1 || name.lenght > 64){
		showMsg(name_limit_length,false);
		return;
	}
	var regex = new RegExp("^([\\u4E00-\\uFA29]|[\\uE7C7-\\uE7F3]|[a-zA-Z0-9]){1,64}$");
	var res = regex.test(name);
	if(!res){
	   showMsg(name_limit,false);
	   return;
	}
	var normalElement = document.getElementById(elementId);
	showLoading();
    $.ajax({
      headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          
      },
      type: form.method,
      url: path,
      data: signFormData(form,false),
      processData:false,
      contentType: false,
     
      success:function(data){
    	  hideLoading();
          if(data != null && data.success){
              showMsg(data.msg,true);
              if(data.data != null){
            	  normalElement.innerText= name;
            	  qrName .title = name;
              }
              normalElement.style.display="";
              form.style.display="none";
          }else if(data != null){
         	 showMsg(data.msg,false);
         	 expireSession(data);
          }
      },
      error:function(err){
    	  hideLoading();
    	  showMsg("服务异常",false);
      }
  }); 
}

function signFormData(form, trim){
	var formData = new FormData(form);
	var timestamp = new Date().getTime();
	formData.append("timestamp", timestamp);
	var arr = [];
    for (var key of formData.keys()) {
        if( arr.indexOf(key) == -1 && key != 'file'){
        	arr.push(key);
        }
    }
    arr.sort();
    var str='';
    for(var i in arr){
    	var a = formData.getAll(arr[i]);
    	var key = arr[i];
    	if(arr[i].endsWith('[]')){
    		key = key.substring(0,key.length -2);
    		for(var j in a){
    			if(trim){
            		var v = a[j].trim();
                    if(v.length != 0){
                    	str +=encodeURIComponent(key+"["+j+"]")+"="+encodeURIComponent(v)+"&"
                    }
            	}else{
            		str +=encodeURIComponent(key+"["+j+"]")+"="+encodeURIComponent(a[j])+"&"
            	}
    			
            }
        }else if(a.length > 1){
        	if(trim){
        		var v = a[a.length-1].trim();
                if(v.length != 0){
                	str +=encodeURIComponent(key)+"="+encodeURIComponent(v)+"&"
                }
        	}else{
        		str +=encodeURIComponent(key)+"="+encodeURIComponent(a[a.length-1])+"&"
        	}
        	
        }else if(a.length == 1){
        	if(trim){
        		var v = a[0].trim();
                if(v.length != 0){
                	str +=encodeURIComponent(key)+"="+encodeURIComponent(v)+"&"
                }
        	}else{
        		var v = a[0];
                str +=encodeURIComponent(key)+"="+encodeURIComponent(v)+"&"
        	}
        }
    	
    }
    var key = formData.get("_token");
    str +=key;
    var sign = md5(str);
    formData.append("sign",sign);
    return formData;
}

