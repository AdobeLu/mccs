<script src="<?php echo e(asset('js/jquery-1.8.3.min.js')); ?>"></script>
<?php if($link != null): ?>
  <?php echo e(include($link)); ?>

<?php else: ?>

<?php endif; ?>
<script>

    $(function(){
    	/* $("img").each(function() {
    		this.src= 
    	}); */

    	$('img').error(function(e){
        	console.log($(this)[0].src);
            console.log($(this));
         });
	});
</script><?php /**PATH D:\www\AppDistribution\resources\views/link.blade.php ENDPATH**/ ?>