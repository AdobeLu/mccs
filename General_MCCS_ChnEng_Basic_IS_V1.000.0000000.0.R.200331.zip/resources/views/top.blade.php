<div class="top">
    	<div class="logo">
    	    @auth
    		   @if(Auth::user()['accountType'] == 'normal')
    		      <a href="{{route('index')}}"><img src="{{asset('image/logo.png')}}"></a>
    		   @else
    		     <img src="{{asset('image/logo.png')}}">
    		   @endif
    		@else 
    		  <a href="{{route('index')}}"><img src="{{asset('image/logo.png')}}"></a>
    		@endauth
    	</div>
    	<div class="user">
               @auth
                    <img src="{{asset('image/user_logo.png')}}" style="display:inline-block;vertival-align:middle;"> 
                    <a href="#" class="userTv" onclick="event.preventDefault();">{{Auth::user()['name']}}</a>
                    <img src="{{asset('image/logout.png')}}" style="display:inline-block;vertival-align:middle;width:27px;height:27px;margin-top:5px;margin-left:10px;cursor:pointer" title="{{ __('common.Logout') }}" onclick="logout('logout-form')"> 
        	        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                        @csrf
                    </form>
                @else
                    <a href="{{route('customLogin')}}" class="login">{{ __('common.Login') }}</a>
                @endauth
        </div>
</div>