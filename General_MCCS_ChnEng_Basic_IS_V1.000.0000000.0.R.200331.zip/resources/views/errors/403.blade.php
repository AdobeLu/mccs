<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>{{ config('app.name', 'MCCS') }}</title>
    <link rel="shortcut icon" href="{{ asset('image/favicon.png') }}">
    <style>
     html,body {
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
        }
      .content {
            width: 300px;
            margin: 0 auto; 
            position: relative;
            top: 50%;
            transform: translateY(-50%);
            text-align:center;
            color:#151C29;
        }
       
        a{
            display:block;
            width:280px;
            height:54px;
            background-color:#007aff;
            text-decoration:none;
            font-size:1.5em;
            text-decoration:none;
            color:#fff;
            margin:40px auto;
            line-height:54px;
            text-align:center;
            border-radius:5px;
            letter-spacing:5px;
        }
    </style>
</head>
<body style="text-align:center;height:100%;background:#fff">
    <div class="content">
        <div  style="font-size: 2em;color:#82868B;letter-spacing:5px;margin: 20px auto;width:200px;text-align:center">{{ __('err.403.msg')}}</div>
    </div>
</body>
</html>